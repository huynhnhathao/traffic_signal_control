import pickle
import gym

from pathlib import Path
import pickle
import gym
import torch
import torch.nn as nn
# how to import or load local files
import os
import sys
path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(path)
import gym_cfg
# with open(path + "/dqn_agent_240.pt", "r") as f:
#     pass




class MLPPolicy(nn.Module):
    def __init__(self, in_dim, out_dim):
        """Create a MLP neural network to be a policy
        parameters: 
            in_dim: int,  input dimension
            out_dim: int, output dimension
        return: logits
        """
        super(MLPPolicy, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        
        self.linear1 = nn.Linear(self.in_dim, 128)
        self.linear2 = nn.Linear(128, 64)
        self.linear3 = nn.Linear(64,self.out_dim )
        self.tanh = nn.Tanh()
        self.softmax = nn.Softmax(dim = 0)
    
    def forward(self, x):
        x = self.linear1(x)
        x = self.tanh(x)
        x = self.linear2(x)
        x = self.tanh(x)
        x = self.linear3(x)
        return x
            

class TestAgent():
    def __init__(self, ):
        self.model = MLPPolicy(24, 8)
        self.load_model()
        #30 sec for each phase
        self.green_sec = 30
        self.last_actions = {}
        self.environment_step = 0

    ################################
    # don't modify this function.
    # agent_list is a list of agent_id
    def load_agent_list(self,agent_list):
        self.agent_list = agent_list
        self.now_phase = dict.fromkeys(self.agent_list,1)
        self.last_change_step = dict.fromkeys(self.agent_list,0)

    # intersections[key_id] = {
    #     'have_signal': bool,
    #     'end_roads': list of road_id. Roads that end at this intersection. The order is random.
    #     'start_roads': list of road_id. Roads that start at this intersection. The order is random.
    #     'lanes': list, contains the lane_id in. The order is explained in Docs.
    # }
    # roads[road_id] = {
    #     'start_inter':int. Start intersection_id.
    #     'end_inter':int. End intersection_id.
    #     'length': float. Road length.
    #     'speed_limit': float. Road speed limit.
    #     'num_lanes': int. Number of lanes in this road.
    #     'inverse_road':  Road_id of inverse_road.
    #     'lanes': dict. roads[road_id]['lanes'][lane_id] = list of 3 int value. Contains the Steerability of lanes.
    #               lane_id is road_id*100 + 0/1/2... For example, if road 9 have 3 lanes, then their id are 900, 901, 902
    # }
    # agents[agent_id] = list of length 8. contains the inroad0_id, inroad1_id, inroad2_id,inroad3_id, outroad0_id, outroad1_id, outroad2_id, outroad3_id
    def load_roadnet(self,intersections, roads, agents):
        self.intersections = intersections
        self.roads = roads
        self.agents = agents
    ################################
    def load_model(self,dir = '' ,step = 240):
        """Load policy model"""
        name = path + "/dqn_agent_{}.pt".format(step)
        model_name = os.path.join(dir, name)
        print("load from " + model_name)
        self.model.load_state_dict(torch.load(model_name))

    def act(self, obs):
        # this function is for inferences, use greedy policy 100%
        observations = obs['observations']
        #info = obs['info']
        actions = {}
        
        # Get state
        observations_for_agent = {}
        for key,val in observations.items():
            observations_agent_id = int(key.split('_')[0])
            observations_feature = key[key.find('_')+1:]
            if(observations_agent_id not in observations_for_agent.keys()):
                observations_for_agent[observations_agent_id] = {}
            observations_for_agent[observations_agent_id][observations_feature] = val[1:]


        # here we use the same actions set in one phase interval

        for k,v in observations_for_agent[self.agent_list[0]].items():
            # the currently second in the environment
            self.environment_step = v[0]
            break
        # if it is time to consider changing phase
        if self.environment_step  % self.green_sec == 0:
            # Get actions
            # inference do not need gradient
            with torch.no_grad():
                for agent in self.agent_list:
                    # plus 1 because action range from 1 to 8, not 0 to 7
                    q_values = self.model(torch.tensor(observations_for_agent[agent]['lane_vehicle_num']).float() )
                    actions[agent] = torch.argmax(q_values).item() + 1
                    #actions[agent] = self.get_action(observations_for_agent[agent]['lane_vehicle_num']) + 1  
            self.last_actions = actions
            return self.last_actions
        else:
            return self.last_actions

scenario_dirs = [
    "test"
]

agent_specs = dict.fromkeys(scenario_dirs, None)
for i, k in enumerate(scenario_dirs):
    # initialize an AgentSpec instance with configuration
    agent_specs[k] = TestAgent()


# after each 40sec, agent at each intersection will change phase, each time it changes phase, redline 5sec
# the reward is how much traffic it has reduce in its intersection