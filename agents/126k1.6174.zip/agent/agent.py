
# from pathlib import Path
import pickle
# import gym

# how to import or load local files
import os
import sys
path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(path)
import gym_cfg
with open(path + "/gym_cfg.py", "r") as f:
    pass
import numpy as np
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__file__)
logger.propagate = False
fh = logging.FileHandler('simulation_data.log')
fh.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

#now we only consider vehicle that near the intersection 100m, on which lane, phase which has more vehicle on its passable lanes 
# will go first
class TestAgent():
    def __init__(self):
        self.count = 0
        self.now_phase = {}
        self.green_sec = 30
        self.max_phase = 8
        self.last_change_step = {}
        self.agent_list = []
        self.phase_passablelane = {}
        self.intersections = {}
        self.roads = {}
        self.agents = {}
        self.intersection_data, self.road_data, self.traffic_signal_data = self.load_data()
        self.road_len = self.get_road_len()
        self.intersection_road_segment = pickle.load(open(path + '/intersection_road_segment.pkl', 'rb'))
        self.road_segment_len = pickle.load(open(path + '/road_segment_len.pkl', 'rb'))


        self.lane_number = { 'road1': {'00': 13, '01': 14, '02': 15  }, 
                            'road2': {'00': 1, '01': 2, '02': 3}, 
                            'road3': {'00': 16, '01': 17, '02': 18}, 
                            'road4': {'00': 4, '01': 5, '02': 6}, 
                            'road5': {'00': 19, '01': 20, '02': 21}, 
                            'road6': {'00': 7, '01': 8, '02': 9}, 
                            'road7': {'00': 22, '01': 23 , '02':24 }, 
                            'road8': {'00':10 , '01': 11, '02':12 ,}
        }
    ################################
    # don't modify this function.
    # agent_list is a list of agent_id
    def load_agent_list(self,agent_list):
        self.agent_list = agent_list
        self.now_phase = dict.fromkeys(self.agent_list,1)
        self.last_change_step = dict.fromkeys(self.agent_list,0)

    # intersections[key_id] = {
    #     'have_signal': bool,
    #     'end_roads': list of road_id. Roads that end at this intersection. The order is random.
    #     'start_roads': list of road_id. Roads that start at this intersection. The order is random.
    #     'lanes': list, contains the lane_id in. The order is explained in Docs.
    # }
    # roads[road_id] = {
    #     'start_inter':int. Start intersection_id.
    #     'end_inter':int. End intersection_id.
    #     'length': float. Road length.
    #     'speed_limit': float. Road speed limit.
    #     'num_lanes': int. Number of lanes in this road.
    #     'inverse_road':  Road_id of inverse_road.
    #     'lanes': dict. roads[road_id]['lanes'][lane_id] = list of 3 int value. Contains the Steerability of lanes.
    #               lane_id is road_id*100 + 0/1/2... For example, if road 9 have 3 lanes, then their id are 900, 901, 902
    # }
    # agents[agent_id] = list of length 8. contains the inroad0_id, inroad1_id, inroad2_id,inroad3_id, outroad0_id, outroad1_id, outroad2_id, outroad3_id
    def load_roadnet(self,intersections, roads, agents):
        self.intersections = intersections
        self.roads = roads
        self.agents = agents
    ################################


    def load_data(self, file_name = '/roadnet_round2.txt'):
        """
        load in road net data, extract len for each road segment id
        """
        data = []
        #dir = os.path.join(sys.path[0],file_name )  
        with open(path + file_name , 'r') as f:
            for line in f.readlines():
                numbers = line.split(' ')
                data.append(list([float(x) for x in numbers ]))

        intersection_data = data[:2049]
        road_data = data[2049:11086]
        traffic_signal_data = data[11086:]
        return intersection_data, road_data, traffic_signal_data

    def get_road_len(self) -> dict:
        # return a dict of road segment len
        road_len = {}
        for x in self.road_data:
            if len(x) == 8:
                road_len[str(int(x[6]))] = x[2]
                road_len[str(int(x[7]))] = x[2] 

        return road_len



    def act(self, obs):

        """ parameters:
            obs: an example: dict_keys(['observations', 'info'])

            {
            'observations': 
            {'0_lane_speed': [190, -2, -2, -2, 0.0, -2, -2, 0.0, 0.0, -2, 0.0, 0.0, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2], 
            '0_lane_vehicle_num': [190, 0, 0, 0, 2, 0, 0, 3, 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},

            'info': {17: {'distance': [30.0], 'drivable': [600.0], 'road': [6.0], 'route': [6.0, 7.0], 'speed': [0.0], 'start_time': [50.0], 't_ff': [3.0]}, 
                26: {'distance': [30.0], 'drivable': [601.0], 'road': [6.0], 'route': [6.0, 1.0], 'speed': [0.0], 'start_time': [80.0], 't_ff': [3.0]}, 
                29: {'distance': [25.0], 'drivable': [600.0], 'road': [6.0], 'route': [6.0, 7.0], 'speed': [0.0], 'start_time': [100.0], 't_ff': [3.0]}, 
                33: {'distance': [30.0], 'drivable': [400.0], 'road': [4.0], 'route': [4.0, 5.0], 'speed': [0.0], 'start_time': [120.0], 't_ff': [3.0]}, 
                35: {'distance': [25.0], 'drivable': [601.0], 'road': [6.0], 'route': [6.0, 1.0], 'speed': [0.0], 'start_time': [120.0], 't_ff': [3.0]},
                    37: {'distance': [30.0], 'drivable': [800.0], 'road': [8.0], 'route': [8.0, 1.0], 'speed': [0.0], 'start_time': [120.0], 't_ff': [3.0]},
                    41: {'distance': [20.0], 'drivable': [600.0], 'road': [6.0], 'route': [6.0, 7.0], 'speed': [0.0], 'start_time': [150.0], 't_ff': [3.0]},
                    45: {'distance': [20.0], 'drivable': [601.0], 'road': [6.0], 'route': [6.0, 1.0], 'speed': [0.0], 'start_time': [160.0], 't_ff': [3.0]},
                    46: {'distance': [25.0], 'drivable': [800.0], 'road': [8.0], 'route': [8.0, 1.0], 'speed': [0.0], 'start_time': [160.0], 't_ff': [3.0]},
                        48: {'distance': [25.0], 'drivable': [400.0], 'road': [4.0], 'route': [4.0, 5.0], 'speed': [0.0], 'start_time': [180.0], 't_ff': [3.0]}, 
                        50: {'distance': [30.0], 'drivable': [801.0], 'road': [8.0], 'route': [8.0, 3.0], 'speed': [0.0], 'start_time': [180.0], 't_ff': [3.0]}}}

        """
        # here obs contains all of the observations and infos

        # observations is returned 'observation' of env.step()
        # info is returned 'info' of env.step()

        #logger.info(str(obs) + '\n')
        observations = obs['observations']
        # an example of observations: {'0_lane_speed': [0, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2], 
        # '0_lane_vehicle_num': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}
        info = obs['info']
        actions = {}

        # a simple fixtime agent

        # preprocess observations
        observations_for_agent = {}


        for key,val in observations.items():
            observations_agent_id = int(key.split('_')[0])
            observations_feature = key[key.find('_')+1:]
            # print(key, val)
            if(observations_agent_id not in observations_for_agent.keys()):
                observations_for_agent[observations_agent_id] = {}
            observations_for_agent[observations_agent_id][observations_feature] = val

        # what observation_for_agent look like?
        """
        {0: {'lane_speed': [190, -2, -2, -2, 0.0, -2, -2, 0.0, 0.0, -2, 0.0, 0.0, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2],
            'lane_vehicle_num': [190, 0, 0, 0, 2, 0, 0, 3, 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}}
        """

       # get actions
        for agent in self.agent_list:
            # select the now_step
            for k,v in observations_for_agent[agent].items():
                # the currently second
                now_step = v[0]
                break
            step_diff = now_step - self.last_change_step[agent]
            if(step_diff >= self.green_sec):
                self.now_phase[agent] = self.get_actions(agent,observations_for_agent[agent], info)
                self.last_change_step[agent] = now_step
            actions[agent] = self.now_phase[agent]
        # print(self.intersections,self.roads,self.agents)
        # actions = self.get_actions(observations_for_agent)
        # self.last_change_step = actions
        return actions
    
    def get_lane_number(self, lane_name, road_name):
        """Get the lane number given lane name and road name"""
        if road_name == 'road2':
            if lane_name == '00':
                return 1
            elif lane_name == '01':
                return 2
            elif lane_name == '02':
                return 3
        elif road_name == 'road4':
            if lane_name == '00':
                return 4
            elif lane_name == '01':
                return 5
            elif lane_name == '02':
                return 6
        elif road_name == 'road6':
            if lane_name == '00':
                return 7
            elif lane_name == '01':
                return 8
            elif lane_name == '02':
                return 9
        elif road_name == 'road8':
            if lane_name == '00':
                return 10
            elif lane_name == '01':
                return 11
            elif lane_name == '02':
                return 12


    def get_actions(self,intersection_id, observation_for_agent, infos, distance = 200):
        """
        number of vehicle on all passable lanes of one phase, from 1 to 8, does not include right turning lanes
        agent is agent id
        observation_for_agent is a dict of lane speed and lane_vehicle_num
        """
        num_vehicle_each_phase = np.zeros(8)
        observation_num_vehicle = observation_for_agent['lane_vehicle_num']
        #check_num_vehicle = self.checking_num_vehicle(intersection_id, infos)
        #assert all([(check_num_vehicle[i] == num_vehicle[i]) or (num_vehicle[i] == -1) for i in range(0, len(num_vehicle))]), f'num_vehicle {num_vehicle} \n checking {check_num_vehicle}'
        # intersection = self.intersection_road_segment[str(int(intersection_id))]
        
        # for vehicle_id, vehicle_info in infos.items():
        #     # is this vehicle on road2?
        #     if str(int(vehicle_info['road'][0])) == intersection['road2']:
        #         # if so, which lane?
        #         drivable =  str(int(vehicle_info['drivable'][0]))
        #         lane_name = drivable[-2:] # '00', '01', '02'

        #         lane_number = self.get_lane_number(lane_name, 'road2')

        #         road_len = self.road_len[intersection['road2']]
        #         assert type(road_len) == float, f'{road_len}  must be float'

        #         if True:#road_len - vehicle_info['distance'][0] <= distance:
        #             if lane_number  == 1:
        #                 num_vehicle_each_phase[0] +=1
        #                 num_vehicle_each_phase[4] +=1

        #             if lane_number == 2:
        #                 num_vehicle_each_phase[1] +=1
        #                 num_vehicle_each_phase[4] +=1

        #     elif str(int(vehicle_info['road'][0])) == intersection['road4']:
                
        #         drivable =  str(int(vehicle_info['drivable'][0]))
        #         lane_name = drivable[-2:] # '00', '01', '02'

        #         lane_number = self.get_lane_number(lane_name, 'road4')

        #         road_len = self.road_len[intersection['road4']]

        #         assert type(road_len) == float, f'{road_len}  must be float'
                
        #         if True: #road_len - vehicle_info['distance'][0] <= distance:
        #             if lane_number  == 4 :
        #                 num_vehicle_each_phase[2] +=1
        #                 num_vehicle_each_phase[5] +=1

        #             if lane_number == 5 :
        #                 num_vehicle_each_phase[3] +=1
        #                 num_vehicle_each_phase[5] +=1

        #     if str(int(vehicle_info['road'][0])) == intersection['road6']:

        #         drivable =  str(int(vehicle_info['drivable'][0]))

        #         lane_name = drivable[-2:] # '00', '01', '02'

        #         lane_number = self.get_lane_number(lane_name, 'road6')

        #         road_len = self.road_len[intersection['road6']]

        #         assert type(road_len) == float, f'{road_len}  must be float'

        #         if True: #road_len - vehicle_info['distance'][0] <= distance:
        #             if lane_number  == 7:
        #                 num_vehicle_each_phase[0] +=1
        #                 num_vehicle_each_phase[6] +=1

        #             if lane_number == 8 :
        #                 num_vehicle_each_phase[3] +=1
        #                 num_vehicle_each_phase[5] +=1

        #     if str(int(vehicle_info['road'][0])) == intersection['road8']:
        #         drivable =  str(int(vehicle_info['drivable'][0]))

        #         lane_name = drivable[-2:] # '00', '01', '02'

        #         lane_number = self.get_lane_number(lane_name, 'road8')

        #         road_len = self.road_len[intersection['road8']]

        #         assert type(road_len) == float, f'{road_len}  must be float'

        #         if True: #road_len - vehicle_info['distance'][0] <= distance:
        #             if lane_number  == 10:
        #                 num_vehicle_each_phase[2] +=1
        #                 num_vehicle_each_phase[7] +=1

        #             if lane_number == 11 :
        #                 num_vehicle_each_phase[3] +=1
        #                 num_vehicle_each_phase[7] +=1

        # for each intersection, we have its roads, for each road, we have its len and speed limit
        # we will count the number of vehicle on a specific road nead n meter intersection
        # then use that number to decide which phase can go first


        # print(f'num_vehicle_each_phase: {num_vehicle_each_phase}')
        # if np.sum(num_vehicle_each_phase) == 0:

        num_vehicle = self.count_num_vehicle_near_intersection(intersection_id, infos, distance )
        # print(f'observation num vehicle: {observation_num_vehicle}')
        # print(f'num vehicle near intersection {num_vehicle}')
        assert len(num_vehicle) == 25
        num_vehicle_each_phase[0] = (num_vehicle[1] + num_vehicle[7]) #1
        num_vehicle_each_phase[1] = (num_vehicle[2] + num_vehicle[8]) #2
        num_vehicle_each_phase[2] = (num_vehicle[10] + num_vehicle[4]) #3
        num_vehicle_each_phase[3] = (num_vehicle[5] + num_vehicle[11]) #4
        num_vehicle_each_phase[4] = (num_vehicle[2] + num_vehicle[1]) # 5
        num_vehicle_each_phase[5] = (num_vehicle[5] + num_vehicle[4]) #6
        num_vehicle_each_phase[6] = (num_vehicle[7] + num_vehicle[8]) #7 
        num_vehicle_each_phase[7] = (num_vehicle[10] + num_vehicle[11]) # 8

        


        action = np.argmax(num_vehicle_each_phase) + 1
        # print(f'num_vehicle_each_phase {num_vehicle_each_phase}')
        # print(f'action selected {action}')
        return action

    # def get_num_vehicle_on_road_lane(self, road_segment , distance, infos):
    #     """
    #     Get number of vehicle on one specific lane of specific road_segment in distance near intersection_id
    #     """
    #     num_vehicle = 0
    #     for vehicle_id,data in infos.items():
    #         if int(data['road']) == 

    def count_num_vehicle_near_intersection(self, intersection_id, infos, distance = 200):
        # count number of vehicle near distance to intersection
        intersection_id = str(int(intersection_id))
        num_vehicle_each_lane = [0]*24
        for vehicle_id, vehicle_info in infos.items():
          
            if str(int(vehicle_info['road'][0])) in [self.intersection_road_segment[intersection_id][key] for key in self.intersection_road_segment[intersection_id].keys() ] :
                
                road_segment_id = str(int(vehicle_info['road'][0]))
                intersection = self.intersection_road_segment[intersection_id]

                drivable = str(int(vehicle_info['drivable'][0]))

                if road_segment_id == intersection['road1']:
                    lane_number = self.which_lane('road1', drivable)

                if road_segment_id == intersection['road2']:
                    lane_number = self.which_lane('road2', drivable)

                if road_segment_id == intersection['road3']:
                    lane_number  = self.which_lane('road3', drivable)

                if road_segment_id == intersection['road4']:
                    lane_number  = self.which_lane('road4', drivable) 

                if road_segment_id == intersection['road5']:
                    lane_number  = self.which_lane('road5', drivable)

                if road_segment_id == intersection['road6']:
                    lane_number  = self.which_lane('road6', drivable)

                if road_segment_id == intersection['road7']:
                    lane_number  = self.which_lane('road7', drivable)

                if road_segment_id == intersection['road8']:
                    lane_number  = self.which_lane('road8', drivable)

                
                this_road_len = self.road_len[road_segment_id]
                if this_road_len - vehicle_info['distance'][0] <= distance:
                    
                    num_vehicle_each_lane[lane_number - 1] += 1

        return [0] + num_vehicle_each_lane

    def which_lane(self, road_name, drivable) -> int:

        lane_name = drivable[-2:] # '00', '01', '02'
        lane_number = self.lane_number[road_name][lane_name]
        return lane_number




    
scenario_dirs = [
    "test"
]

agent_specs = dict.fromkeys(scenario_dirs, None)
for i, k in enumerate(scenario_dirs):
    # initialize an AgentSpec instance with configuration
    agent_specs[k] = TestAgent()


# after each 40sec, agent at each intersection will change phase, each time it changes phase, redline 5sec
# the reward is how much traffic it has reduce in its intersection