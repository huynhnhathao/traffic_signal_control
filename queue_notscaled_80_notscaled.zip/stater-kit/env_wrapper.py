from numpy.lib.arraysetops import isin
import CBEngine
import gym 
import numpy as np
import pickle
from TrainingUtilities import *
import os
import sys
import multiprocessing
path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(path)
# with open(path + "/cfg/gym_cfg.py", "r") as f:
#     pass
from copy import deepcopy

class gym_cfg():
    def __init__(self):
        self.cfg = {
            'observation_features':['lane_speed','lane_vehicle_num']
        }
class CBEngineWrapper(gym.Wrapper):
    """
    A wrapper for CBEngine environment
    this wrapper preprocess observations and rewards

    """
    def __init__(self, env, engine_step = 3) -> None:
        super().__init__(env)
        self.env = env
        self.engine_step = engine_step

        
        
        
        self.lane_number = { 'road1': {'00': 13, '01': 14, '02': 15  }, 
                            'road2': {'00': 1, '01': 2, '02': 3}, 
                            'road3': {'00': 16, '01': 17, '02': 18}, 
                            'road4': {'00': 4, '01': 5, '02': 6}, 
                            'road5': {'00': 19, '01': 20, '02': 21}, 
                            'road6': {'00': 7, '01': 8, '02': 9}, 
                            'road7': {'00': 22, '01': 23 , '02':24 }, 
                            'road8': {'00':10 , '01': 11, '02':12 ,}
        }

        self.intersection_road_segment = pickle.load(open(path + '/intersection_road_segment1.pkl', 'rb'))
        self.road_segment_len = pickle.load(open(path + '/road_segment_len.pkl', 'rb'))

        self.convert_lane = {1:19, 2:20, 3:21, 4:22, 5:23, 6:24, 7:13, 8:14, 9:15, 10:16, 11:17, 12:18, 
                            13:7, 14:8, 15:9, 16:10, 17:11, 18:12, 19:1, 20:2, 21:3, 22:4, 23: 5, 24:6 }

        self.intersection_data, self.road_data, self.traffic_signal_data = self.load_data()
        self.agent_list = list(self.intersection_road_segment.keys())

        self.road_len = self.get_road_len()
        self.neighbor_intersection_data = pickle.load(open(path + '/neighbor_intersection_data.pkl', 'rb'))

        self.last_change_phase = dict.fromkeys(self.agent_list, 1 )
        self.onehot_last_change_phase = self.init_onehot_last_change_phase()

        self.vehicles_on_roads_ = pickle.load(open(path + '/vehicles_on_roads.pkl', 'rb'))
        # """
        # {'1': {'from_inter': '22296635640',
        #     'to_inter': '41704581960',
        #     'num_vehicle_on_lanes': {'lane00': [0, 0, 0],
        #     'lane01': [0, 0, 0],
        #     'lane02': [0, 0, 0]},
        #     'num_vehicle_waiting_on_lanes': {'lane00': [0, 0, 0],
        #     'lane01': [0, 0, 0],
        #     'lane02': [0, 0, 0]}},
        # }
        # """

        self.reset_vehicles_on_roads()


    def init_onehot_last_change_phase(self, ) -> dict:
        d = {}
        for agent in self.agent_list:
            d[str(agent)] = [0]*8

        return d

    def reset_vehicles_on_roads(self):
        self.vehicles_on_roads = deepcopy(self.vehicles_on_roads_)

    def load_data(self, file_name = '/data/roadnet_round2.txt'):
        """
        load in road net data, extract len for each road segment id
        """
        data = []
        #dir = os.path.join(sys.path[0],file_name )  
        with open(path + file_name , 'r') as f:
            for line in f.readlines():
                numbers = line.split(' ')
                data.append(list([float(x) for x in numbers ]))

        intersection_data = data[:2049]
        road_data = data[2049:11086]
        traffic_signal_data = data[11086:]
        return intersection_data, road_data, traffic_signal_data

    def get_road_len(self) -> dict:
        # return a dict of road segment len
        road_len = {}
        for x in self.road_data:
            if len(x) == 8:
                road_len[str(int(x[6]))] = x[2]
                road_len[str(int(x[7]))] = x[2] 

        return road_len


    def update_vehicles_on_roads(self, infos, min_speed = 1):
        """
        this method update the number of vehicles on all roads segment of the road network
        each road_id is a dict, contains number of vehicle on its lanes's segments and number of vehicle that not moving 
        and the from_intersection and to intersection
        """
        self.reset_vehicles_on_roads()
        for vehicle_id, info in infos.items():
            road_id_of_this_vehicle = str(int(info['road'][0]))
            drivable = str(int(info['drivable'][0]))
            lane_of_this_vehicle = drivable[-2:]
            this_road_len = self.road_len[road_id_of_this_vehicle]

            segment = None
            # segment 0 is the nearest entering intersection
            if info['distance'][0] <= this_road_len/3:
                segment = 2
            elif info['distance'][0] <= (2/3)*this_road_len:
                segment = 1
            else:
                segment = 0

            self.vehicles_on_roads[road_id_of_this_vehicle]['num_vehicle_on_lanes'][f'lane{lane_of_this_vehicle}'][segment] += 1

            if info['speed'][0] < min_speed:
                self.vehicles_on_roads[road_id_of_this_vehicle]['num_vehicle_waiting_on_lanes'][f'lane{lane_of_this_vehicle}'][segment] += 1

  
    def which_road(self, lane_number):
        # take in a lane number and return which road that lane in
        if lane_number in [1,2,3]:
            return 'road2'
        elif lane_number in [13, 14, 15]:
            return 'road1'
        elif lane_number in [4, 5, 6]:
            return 'road4'
        elif lane_number in [16,17,18]:
            return 'road3'
        elif lane_number in [7,8,9]:
            return 'road6'
        elif lane_number in [19,20,21]:
            return 'road5'
        elif lane_number in [10, 11, 12]:
            return 'road8'
        elif lane_number in [22,23,24]:
            return 'road7'

    def get_neighbor_data(self, intersection_id, lane_number, segment):
        """
        return neighbor intersection of intersection_id that link with it via road_name, 
        and lane number w.r.t the neighbor, and segment of vehicle w.r.t the neighbor
        neighbor_lane is counted from 1 -> 24
        """
        neighbor_intersection_ids = self.neighbor_intersection_data[intersection_id]
        road = self.which_road(lane_number)
        if road not in neighbor_intersection_ids.keys():
            return (None, None, None)
        else:
            neighbor_intersection_id = neighbor_intersection_ids[road]

        neighbor_lane_number = self.convert_lane[lane_number]
        neighbor_segment = None
        if segment == 0:
            neighbor_segment = 2
        elif segment == 1:
            neighbor_segment = 1
        elif segment == 2:
            neighbor_segment = 0
        if neighbor_segment is None:
            raise ValueError('can not convert neighbor segment')

        return (neighbor_intersection_id, neighbor_lane_number, neighbor_segment)

    def normalize_num_vehicles(self, num_vehicles):
        """
        normalize num_vehicle of segments of lanes of each intersection by its segment len(segment len = lane_len / 3 )
        """
        for intersection_id in num_vehicles.keys():
            assert len(num_vehicles[intersection_id]) == 24*3
            this_intersection_data = self.intersection_road_segment[intersection_id]
            # print(f'before transform {num_vehicles[intersection_id]}')
            for road_name, data in this_intersection_data.items():
                # for each road name in this intersection
                if data['id'] != '-1':
                    
                    # if this road of this intersection exist
                    lanes = list((np.array(list  (self.lane_number[road_name].values())  ) - 1)*3 )
                    temp_lanes = []
                    for lane in lanes:
                        temp_lanes.extend([lane +1, lane + 2])

                    lanes.extend(temp_lanes)

                    try:
                        segment_len = data['len']/15 # 3*5
                    except:
                        print(f"id {data['id']} len {data['len']} ")
        
                    num_vehicles[intersection_id][lanes]/= segment_len

            #         print(f"road name {road_name}  lanes {lanes} segmentlen {segment_len} len {data['len']}")
            # print(f'after transform {num_vehicles[intersection_id]}')


        return num_vehicles

    def get_unavailable_phases(self, lane_vehicle_num):
        self.phase_lane_map_in = [[1, 7], [2, 8], [4, 10], [5, 11], [2, 1], [5, 4], [8, 7], [11, 10]]
        unavailable_phases = []
        not_exist_lanes = []
        for i in range(1, 25):
            if lane_vehicle_num[i] < 0:
                not_exist_lanes.append(i)
        for lane in not_exist_lanes:
            for phase_id, in_lanes in enumerate(self.phase_lane_map_in):
                phase_id += 1
                if lane in in_lanes and phase_id not in unavailable_phases:
                    unavailable_phases.append(phase_id)

        return unavailable_phases

    def which_lane(self, road_name, drivable) -> int:

        lane_name = drivable[-2:] # '00', '01', '02'
        lane_number = self.lane_number[road_name][lane_name]
        return lane_number

    def update_last_change_phase(self,actions ) -> None:
        """
        update the last change phase dict
        """
        for agent in self.agent_list:
            self.onehot_last_change_phase[str(agent)][actions[str(agent)] - 1] = 1

        # print('update completed')

    def step(self, actions):
        """
        action is expected to be a dict, its keys are agent id and its values are action phase for that agent
        """
        # step self.engine_step with the same set of actions into the environment
        # if isinstance(actions[self.agent_list[0]] ,np.ndarray):
        #     new_actions = {}
        #     for agent in actions.keys():
        #         new_actions[int(agent)] = actions[agent][0]

        #     actions = new_actions

        self.update_last_change_phase(actions)

        if isinstance(list(actions.keys())[0], str):
            new_actions = {}
            for intersection_id, action in actions.items():
                new_actions[int(intersection_id)] = action
            actions = new_actions

        if not isinstance(actions, dict):
            raise ValueError('Action must be a dict')

        for _ in range(self.engine_step):
            observations, rewards, dones, infos = self.env.step(actions)

        
        # extract observation for agent into a dict

        # observations_for_agent = {}
        # for key,val in observations.items():
        #     observations_agent_id = int(key.split('_')[0])
        #     # observations_feature = key[key.find('_')+1:]
            
        #     if(observations_agent_id not in observations_for_agent.keys()):
        #         # observations_for_agent[str(observations_agent_id)] = {}
        #         observations_for_agent[str(observations_agent_id)] = val[1:]

        # create new observations and rewards, each is a dict

        self.update_vehicles_on_roads(infos)
        new_observations, new_rewards = self.get_new_observations_and_rewards()

        done = all(list(dones.values()))


        # print('completed one step' + '+'*100, f'done = {done}')

        return new_observations, new_rewards,done, {}


    
    def get_onehot_current_phase(self, action):

        current_phase = [0]*8
        current_phase[action - 1] = 1
        return current_phase

    def reset(self):
        observations, infos = self.env.reset()

        # extract observation for agent into a dict
        observations_for_agent = {}
        for key,val in observations.items():
            observations_agent_id = int(key.split('_')[0])
            observations_feature = key[key.find('_')+1:]
            if(observations_agent_id not in observations_for_agent.keys()):
                observations_for_agent[str(observations_agent_id)] = {}
            observations_for_agent[str(observations_agent_id)][observations_feature] = val

        # create new observations and rewards, each is a dict

        new_observations, new_rewards = self.get_new_observations_and_rewards()

        return new_observations, {}

    def get_new_observations_and_rewards(self,):
        """
        take in info of one state, 
        return a dict, its keys are agent list, its values is a list of 24*3 element
        each lane has 3 segment, we use the number of vehicle on each segment, from nearest 
        intersection out, (normalized by the segment length)
        """
        observations = {}
        queuelen_rewards = {}
        for agent_id, agent_info in self.intersection_road_segment.items():
            observations[agent_id] = [0]*80
            observations[agent_id][-8:] = self.onehot_last_change_phase[str(agent_id)]
            
            # get observation for this agent
            if agent_info['road2']['id'] != '-1':
                this_road_id = agent_info['road2']['id']
                observations[agent_id][:3] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00'])) /(agent_info['road2']['len']/15))
                observations[agent_id][3:6] = list( np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01'])) /(agent_info['road2']['len']/15))
                observations[agent_id][6:9] = list( np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road2']['len']/15))

                queue_on_road2 = sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane00']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane01']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane02'])
                # queue_on_road2 =  queue_on_road2 / (agent_info['road2']['len']/ 5) # scale the total number of waiting vehicle to road's capacity
            else:
                # if this road is not exist, then pad the number of vehicle by -1
                observations[agent_id][:9] = [-1]*9

            if agent_info['road4']['id'] != '-1':
                this_road_id = agent_info['road4']['id']
                observations[agent_id][9:12] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']))/(agent_info['road4']['len']/15))
                observations[agent_id][12:15] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']))/(agent_info['road4']['len']/15))
                observations[agent_id][15:18] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road4']['len']/15))

                queue_on_road4 = sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane00']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane01']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane02'])
                # queue_on_road4 =  queue_on_road4 / (agent_info['road4']['len']/ 5)
            else:
                observations[agent_id][9:18] = [-1]*9

            if agent_info['road6']['id'] != '-1':
                this_road_id = agent_info['road6']['id']
                observations[agent_id][18:21] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']))/(agent_info['road6']['len']/15))
                observations[agent_id][21:24] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']))/(agent_info['road6']['len']/15))
                observations[agent_id][24:27] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road6']['len']/15))

                queue_on_road6 = sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane00']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane01']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane02'])
                # queue_on_road6 =  queue_on_road6 / (agent_info['road6']['len']/ 5)
            else:
                observations[agent_id][18:27] = [-1]*9

            if agent_info['road8']['id'] != '-1':
                this_road_id = agent_info['road8']['id']
                observations[agent_id][27:30] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']))/(agent_info['road8']['len']/15))
                observations[agent_id][30:33] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']))/(agent_info['road8']['len']/15))
                observations[agent_id][33:36] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road8']['len']/15))

                queue_on_road8 = sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane00']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane01']) + sum(self.vehicles_on_roads[this_road_id]['num_vehicle_waiting_on_lanes']['lane02'])
                # queue_on_road8 =  queue_on_road8 / (agent_info['road8']['len']/ 5)
            else:
                observations[agent_id][27:36] = [-1]*9

            if agent_info['road1']['id'] != '-1':
                this_road_id = agent_info['road1']['id']
                observations[agent_id][36:39] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road1']['len']/15))
                observations[agent_id][39:42] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']))/(agent_info['road1']['len']/15))
                observations[agent_id][42:45] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']))/(agent_info['road1']['len']/15))
            else:
                observations[agent_id][36:45] =[-1]*9

            if agent_info['road3']['id'] != '-1':
                this_road_id = agent_info['road3']['id']
                observations[agent_id][45:48] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road3']['len']/15))
                observations[agent_id][48:51] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']))/(agent_info['road3']['len']/15))
                observations[agent_id][51:54] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']))/(agent_info['road3']['len']/15))
            else:
                observations[agent_id][45:54] = [-1]*9   

            if agent_info['road5']['id'] != '-1':
                this_road_id = agent_info['road5']['id']
                observations[agent_id][54:57] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road5']['len']/15))
                observations[agent_id][57:60] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']))/(agent_info['road5']['len']/15))
                observations[agent_id][60:63] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']))/(agent_info['road5']['len']/15))
            else:
                observations[agent_id][54:63] = [-1]*9                       

            if agent_info['road7']['id'] != '-1':
                this_road_id = agent_info['road7']['id']
                observations[agent_id][63:66] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']))/(agent_info['road7']['len']/15))
                observations[agent_id][66:69] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']))/(agent_info['road7']['len']/15))
                observations[agent_id][69:72] = list(np.array((self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']))/(agent_info['road7']['len']/15))
            else:
                observations[agent_id][63:72] = [-1]*9     

            queuelen_rewards[agent_id] = -(queue_on_road2 + queue_on_road4 + queue_on_road6 + queue_on_road8)

           
        # scaled_num_vehicles = self.normalize_num_vehicles(deepcopy(observations))
        return observations, queuelen_rewards

    def compute_pressure_of_one_movement(self, num_vehicles, lane_number):
        # lane number count from 1 to 24
        if lane_number in [1, 9, 11]:
            mean_vehicle_exiting = self.get_num_vehicle_on_road('road3',num_vehicles)/3
        elif lane_number in [2, 12, 4]:
            mean_vehicle_exiting = self.get_num_vehicle_on_road('road5',num_vehicles)/3
        elif lane_number in [5, 7, 3]:
            mean_vehicle_exiting = self.get_num_vehicle_on_road('road7',num_vehicles)/3

        elif lane_number in [6, 8, 10]:
            mean_vehicle_exiting = self.get_num_vehicle_on_road('road1',num_vehicles)/3


        # pressure of a traffic movement (l, m) is the difference between num_vehicle on lane l and num_vehicle on lane m
        pressure = (num_vehicles[(lane_number - 1)*3] + num_vehicles[(lane_number - 1)*3 + 1] +  num_vehicles[(lane_number - 1)*3 + 2]  - mean_vehicle_exiting)
        return (pressure)


    def get_pressure_rewards(self, num_vehicles, observation_for_agents):
        """
        get new reward for all agents
        pressure compute on the first segment of the lane
        """
        # normalized number of vehicle on each segment with its segment len
        num_vehicles = self.normalize_num_vehicles(deepcopy(num_vehicles))

        rewards = {}
        for intersection_id in self.agent_list:
            rewards[intersection_id] = 0

        for intersection_id in rewards.keys():
            num_vehicle_of_this_intersection = num_vehicles[intersection_id]

            non_existen_lanes = self.get_non_existen_lanes(observation_for_agents[intersection_id]['lane_vehicle_num'])
            pressures = [self.compute_pressure_of_one_movement(num_vehicle_of_this_intersection, x) for x in [1,2,3,4,5,6,7,8,9,10,11,12] if x not in non_existen_lanes]
            pressure = -abs(np.sum(pressures))
            rewards[intersection_id] = pressure

        return rewards

    def get_non_existen_lanes(self, lane_vehicle_num):
        non_existen_lanes = []
        for i, num in enumerate(lane_vehicle_num):
            if num < 0:
                non_existen_lanes.append(i)
        return non_existen_lanes


def spawn_env(simulator_cfg_file = path+  '/cfg/simulator.cfg',  metric_period = 200):
    gym_cfg_instance = gym_cfg()
    gym_configs = gym_cfg_instance.cfg
    # simulator_configs = read_config(simulator_cfg_file)
    env = gym.make(
        'CBEngine-v0',
        simulator_cfg_file=simulator_cfg_file,
        thread_num=1,
        gym_dict=gym_configs,
        metric_period=metric_period
    )
    env.set_warning(0)
    env.set_log(0)
    env.set_ui(0)
    # env.set_info(1)
    wrapped_env =CBEngineWrapper(env)
    return wrapped_env

if __name__ == '__main__':
    env = spawn_env()
    obs, infos = env.reset()
    dones = False
    while not dones:
        obs,rewards, dones, infos = env.step(dict.fromkeys(env.agent_list, 1))
    # print(env.action_space.sample())
    #print(obs, rewards, dones, infos)


