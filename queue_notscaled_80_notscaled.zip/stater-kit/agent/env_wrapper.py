import CBEngine
import gym 
import numpy as np
import pickle
from TrainingUtilities import *
import os
import sys
path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(path)
with open(path + "/gym_cfg.py", "r") as f:
    pass
class gym_cfg():
    def __init__(self):
        self.cfg = {
            'observation_features':['lane_speed','lane_vehicle_num']
        }
class CBEngineWrapper(gym.Wrapper):
    """
    A wrapper for CBEngine environment

    """
    def __init__(self, env, engine_step = 3) -> None:
        super().__init__(env)
        self.env = env
        self.engine_step = engine_step
        
        self.lane_number = { 'road1': {'00': 13, '01': 14, '02': 15  }, 
                            'road2': {'00': 1, '01': 2, '02': 3}, 
                            'road3': {'00': 16, '01': 17, '02': 18}, 
                            'road4': {'00': 4, '01': 5, '02': 6}, 
                            'road5': {'00': 19, '01': 20, '02': 21}, 
                            'road6': {'00': 7, '01': 8, '02': 9}, 
                            'road7': {'00': 22, '01': 23 , '02':24 }, 
                            'road8': {'00':10 , '01': 11, '02':12 ,}
        }

        self.intersection_road_segment = pickle.load(open(path + '/intersection_road_segment.pkl', 'rb'))
        self.road_segment_len = pickle.load(open(path + '/road_segment_len.pkl', 'rb'))

        self.agent_list = []

        self.intersection_data, self.road_data, self.traffic_signal_data = self.load_data()
        self.road_len = self.get_road_len()


    def load_data(self, file_name = '/roadnet_round2.txt'):
        """
        load in road net data, extract len for each road segment id
        """
        data = []
        #dir = os.path.join(sys.path[0],file_name )  
        with open(path + file_name , 'r') as f:
            for line in f.readlines():
                numbers = line.split(' ')
                data.append(list([float(x) for x in numbers ]))

        intersection_data = data[:2049]
        road_data = data[2049:11086]
        traffic_signal_data = data[11086:]
        return intersection_data, road_data, traffic_signal_data

    def get_road_len(self) -> dict:
        # return a dict of road segment len
        road_len = {}
        for x in self.road_data:
            if len(x) == 8:
                road_len[str(int(x[6]))] = x[2]
                road_len[str(int(x[7]))] = x[2] 

        return road_len


    def check_road(self, road_segment_id):
        # check if this road_segment_id is one of the exitting roads of signalized intersection

        for line in self.traffic_signal_data:
            if road_segment_id in line:
                print(line)
                return True


    def which_intersection(self, vehicle_info):
        """
        return which intersection this vehicle belong to
        """

        road_id = str(int(vehicle_info['road'][0]))

        for intersection_id, road_ids in self.intersection_road_segment.items():

            for road in road_ids.keys():
                if road_id == road_ids[road] and road in ['road2', 'road4' , 'road6', 'road8']:
                        
                    drivable = str(int(vehicle_info['drivable'][0]))
                    lane_number = self.which_lane(road, drivable)
 
                    this_road_len = self.road_len[road_id]
                    if this_road_len - vehicle_info['distance'][0] <= 200:
                        #print(f'intersection {intersection_id} road_id {road_ids[road]} road_name {road} drivable {drivable} lane_number {lane_number } len road {this_road_len} ')
                        return (intersection_id, lane_number)
                    else:
                        return (None, None)
        return (None, None)

    def step(self, action):
        #action is expected to be a dict
        # step n times with the same actions
        for _ in range(3):
            observation, reward, done, info = self.env.step(action)
        # create new observation

        new_observation = self.get_new_observation(info)
        new_reward = self.get_new_reward()
        
        return new_observation, new_reward, done, {}

    def reset(self):
        observation, info = self.env.reset()
        #new_observation = self.get_new_observation(info)
        return observation#new_observation

    def get_new_observation(self, info):
        """
        take in info of one state, 
        return a dict, its keys are agent list, its values is a list of 24*3 element
        each lane has 3 segment, we use the number of vehicle on each segment, from nearest 
        intersection out, normalized by the segment length
        """
        num_vehicles = {}
        for intersection_id in self.agent_list:
            num_vehicles[str(intersection_id)] = np.zeros(24)


        for vehicle_id, vehicle_info in info.items():
            intersection, lane_number = self.which_intersection(vehicle_info)

            if intersection is None:
                continue
            num_vehicles[intersection][lane_number - 1] += 1

        assert len(num_vehicles.keys()) == len(self.agent_list)
        return num_vehicles



def spawn_env(simulator_cfg_file = path+  '/simulator.cfg',  metric_period = 200):
    gym_cfg_instance = gym_cfg()
    gym_configs = gym_cfg_instance.cfg
    simulator_configs = read_config(simulator_cfg_file)
    env = gym.make(
        'CBEngine-v0',
        simulator_cfg_file=simulator_cfg_file,
        thread_num=1,
        gym_dict=gym_configs,
        metric_period=metric_period
    )

if __name__ == '__main__':
    env = spawn_env()

    print(len(env.intersection_road_segment))