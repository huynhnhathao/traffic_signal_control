import torch
from collections import deque
import random
class MemoryReplay(object):
    """Memmory class to save experiences"""
    def __init__(self, maxlen,batch_size, seed, device):
        """
        params:
            maxlen: max len of memory
            batch_size: number of experiences are sampled each time sample is called
            seed: set seed for random, for reproducible purpose
        """
        self.maxlen = maxlen
        self.seed = seed
        self.memory = deque(maxlen  = self.maxlen)
        self.experience = namedtuple('Experience', field_names= ['state', 'action', 'reward', 'next_state', 'done'])
        self.batch_size = batch_size
        self.device = device
        random.seed(self.seed)

    
    def sample(self, n_experiences = None):
        """
        Sample n_experiences from the memory
        return pytorch tensors of experiences: states, actions, rewards, next_states, dones 
        """
        if n_experiences is None:
            n_experiences = self.batch_size
        
        samples = random.sample(self.memory, n_experiences)
        states, actions, rewards, next_states, dones = np.array([x.state for x in samples]) , np.array([x.action for x in samples]), np.array([x.reward for x in samples]),\
         np.array([x.next_state for x in samples]), np.array([x.done for x in samples])
         
        # logger.info(f'1 example of experience sample from memory: state: {states[0]} action: {actions[0]} reward {rewards[0]} next_state: {next_states[0]} done: {dones[0]}')
        assert type(states) == np.ndarray, 'states is expected to be np.ndarray'
        assert len(states) == len(actions) == len(rewards) == len(next_states) == len(dones), 'len does not match'
        # ndarray into pytorch tensors
        states = torch.from_numpy(states).float().to(self.device)
        actions = torch.from_numpy(actions).float().unsqueeze(-1).to(self.device)
        rewards = torch.from_numpy(rewards).float().unsqueeze(-1).to(self.device)
        next_states = torch.from_numpy(next_states).float().to(self.device)
        dones = torch.from_numpy(dones).float().unsqueeze(-1).to(self.device)
        # logger.info(f'Shape of tensor return from memory class: \n states.size() = {states.size()}, actions.size() = {actions.size()}, rewards.size() = {rewards.size()}, next_states.size() = {next_states.size()}, dones.size() = {dones.size()}')
        # is the shape right?
        return states, actions, rewards, next_states, dones

        

    def add_experiences(self, experiences):
        """
        Add many experiences to the memory
        Experiences is expected to be a list of lists: states, actions, rewards, next_states, dones
        """
        num_experiences = len(experiences[0])
        assert type(experiences) == list, 'Experiences is expected to be a list of lists: state, action, reward, next_state, done'
        self.memory.extend([self.experience(state, action, reward, next_state, done) for state, action, reward,next_state,  done in zip(*experiences)])
        # logger.info(f'Add {num_experiences} experiences to memory, below are five last added experiences: ')
        # for i in range(5):
        #     experience = self.memory[-i]
        #     logger.info(f"{i}. state: {experience.state} action: {experience.action} reward: {experience.reward} next_state: {experience.next_state} done: {experience.done} ")

    def __len__(self):
        return len(self.memory)