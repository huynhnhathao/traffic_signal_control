
# from pathlib import Path
import pickle
# import gym
import concurrent.futures
# how to import or load local files
import os
import sys
path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(path)
import gym_cfg
with open(path + "/gym_cfg.py", "r") as f:
    pass
import numpy as np
import logging


#now we only consider vehicle that near the intersection 100m, on which lane, phase which has more vehicle on its passable lanes 
# will go first
class TestAgent():
    def __init__(self):
        self.count = -1
        self.now_phase = {}
        self.green_sec = 30
        self.max_phase = 8
        self.last_change_step = {}
        self.agent_list = []
        self.phase_passablelane = {}
        self.intersections = {}
        self.roads = {}
        self.agents = {}
        self.intersection_data, self.road_data, self.traffic_signal_data = self.load_data()
        self.road_len = self.get_road_len()
        self.intersection_road_segment = pickle.load(open(path + '/intersection_road_segment.pkl', 'rb'))
        self.road_segment_len = pickle.load(open(path + '/road_segment_len.pkl', 'rb'))


        self.lane_number = { 'road1': {'00': 13, '01': 14, '02': 15  }, 
                            'road2': {'00': 1, '01': 2, '02': 3}, 
                            'road3': {'00': 16, '01': 17, '02': 18}, 
                            'road4': {'00': 4, '01': 5, '02': 6}, 
                            'road5': {'00': 19, '01': 20, '02': 21}, 
                            'road6': {'00': 7, '01': 8, '02': 9}, 
                            'road7': {'00': 22, '01': 23 , '02':24 }, 
                            'road8': {'00':10 , '01': 11, '02':12 ,}
        }
    ################################
    # don't modify this function.
    # agent_list is a list of agent_id
    def load_agent_list(self,agent_list):
        self.agent_list = agent_list
        self.now_phase = dict.fromkeys(self.agent_list,1)
        self.last_change_step = dict.fromkeys(self.agent_list,0)

    # intersections[key_id] = {
    #     'have_signal': bool,
    #     'end_roads': list of road_id. Roads that end at this intersection. The order is random.
    #     'start_roads': list of road_id. Roads that start at this intersection. The order is random.
    #     'lanes': list, contains the lane_id in. The order is explained in Docs.
    # }
    # roads[road_id] = {
    #     'start_inter':int. Start intersection_id.
    #     'end_inter':int. End intersection_id.
    #     'length': float. Road length.
    #     'speed_limit': float. Road speed limit.
    #     'num_lanes': int. Number of lanes in this road.
    #     'inverse_road':  Road_id of inverse_road.
    #     'lanes': dict. roads[road_id]['lanes'][lane_id] = list of 3 int value. Contains the Steerability of lanes.
    #               lane_id is road_id*100 + 0/1/2... For example, if road 9 have 3 lanes, then their id are 900, 901, 902
    # }
    # agents[agent_id] = list of length 8. contains the inroad0_id, inroad1_id, inroad2_id,inroad3_id, outroad0_id, outroad1_id, outroad2_id, outroad3_id
    def load_roadnet(self,intersections, roads, agents):
        self.intersections = intersections
        self.roads = roads
        self.agents = agents
    ################################


    def load_data(self, file_name = '/roadnet_round2.txt'):
        """
        load in road net data, extract len for each road segment id
        """
        data = []
        #dir = os.path.join(sys.path[0],file_name )  
        with open(path + file_name , 'r') as f:
            for line in f.readlines():
                numbers = line.split(' ')
                data.append(list([float(x) for x in numbers ]))

        intersection_data = data[:2049]
        road_data = data[2049:11086]
        traffic_signal_data = data[11086:]
        return intersection_data, road_data, traffic_signal_data

    def get_road_len(self) -> dict:
        # return a dict of road segment len
        road_len = {}
        for x in self.road_data:
            if len(x) == 8:
                road_len[str(int(x[6]))] = x[2]
                road_len[str(int(x[7]))] = x[2] 

        return road_len


    def check_road(self, road_segment_id):
        # check if this road_segment_id is one of the exitting roads of signalized intersection

        for line in self.traffic_signal_data:
            if road_segment_id in line:
                print(line)
                return True

    def which_intersection(self, vehicle_info):
        """
        return which intersection this vehicle belong to
        """

        road_id = str(int(vehicle_info['road'][0]))

        for intersection_id, road_ids in self.intersection_road_segment.items():

            for road in road_ids.keys():
                if road_id == road_ids[road] and road in ['road2', 'road4' , 'road6', 'road8']:
                        
                    drivable = str(int(vehicle_info['drivable'][0]))
                    lane_number = self.which_lane(road, drivable)
 
                    this_road_len = self.road_len[road_id]
                    if this_road_len - vehicle_info['distance'][0] <= 200:
                        #print(f'intersection {intersection_id} road_id {road_ids[road]} road_name {road} drivable {drivable} lane_number {lane_number } len road {this_road_len} ')
                        return (intersection_id, lane_number)
                    else:
                        return (None, None)
        return (None, None)


    def act(self, obs):
        self.count += 1
        if  self.count %3 == 0:
            pass
        else:
            return {}
        observations = obs['observations']
        # an example of observations: {'0_lane_speed': [0, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2], 
        # '0_lane_vehicle_num': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}
        info = obs['info']
        num_vehicles = {}
        for intersection_id in self.agent_list:
            num_vehicles[str(intersection_id)] = np.zeros(24)



        # with concurrent.futures.ProcessPoolExecutor() as executor:
        #     results = executor.map(self.which_intersection, info.values())

        # for result in results:
        #     if result[0] is not None:
        #         num_vehicles[result[0]][result[1] - 1] += 1



        for vehicle_id, vehicle_info in info.items():
            intersection, lane_number = self.which_intersection(vehicle_info)

            if intersection is None:
                continue
            num_vehicles[intersection][lane_number - 1] += 1



           # print(f'intersection id {intersection} lane number {lane_number} num vehicle {num_vehicles[intersection]}')
            

        actions = {}    

        # a simple fixtime agent

        # preprocess observations
        observations_for_agent = {}


        for key,val in observations.items():
            observations_agent_id = int(key.split('_')[0])
            observations_feature = key[key.find('_')+1:]
            # print(key, val)
            if(observations_agent_id not in observations_for_agent.keys()):
                observations_for_agent[observations_agent_id] = {}
            observations_for_agent[observations_agent_id][observations_feature] = val

        # what observation_for_agent look like?
        """
        {0: {'lane_speed': [190, -2, -2, -2, 0.0, -2, -2, 0.0, 0.0, -2, 0.0, 0.0, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2],
            'lane_vehicle_num': [190, 0, 0, 0, 2, 0, 0, 3, 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}}
        """

       # get actions
        for agent in self.agent_list:
            # select the now_step
            for k,v in observations_for_agent[agent].items():
                # the currently second
                now_step = v[0]
                break
            step_diff = now_step - self.last_change_step[agent]
            if(step_diff >= self.green_sec):
                self.now_phase[agent] = self.get_actions(agent, num_vehicles[str(agent)])
                self.last_change_step[agent] = now_step
            actions[agent] = self.now_phase[agent]
        # print(self.intersections,self.roads,self.agents)
        # actions = self.get_actions(observations_for_agent)
        # self.last_change_step = actions
        return actions

    def get_actions(self,intersection_id,num_vehicle,  distance = 200):
        """
        number of vehicle on all passable lanes of one phase, from 1 to 8, does not include right turning lanes
        agent is agent id
        observation_for_agent is a dict of lane speed and lane_vehicle_num
        """
        num_vehicle_each_phase = np.zeros(8)

        #num_vehicle = self.count_num_vehicle_near_intersection(intersection_id, new_info, distance )
        # print(f'observation num vehicle: {observation_num_vehicle}')
        # print(f'num vehicle near intersection {num_vehicle}')
   
  
        num_vehicle = [0] + list(num_vehicle)
        # print(intersection_id)
        # print(num_vehicle)
        #assert len(num_vehicle) == 25
        num_vehicle_each_phase[0] = (num_vehicle[1] + num_vehicle[7]) #1
        num_vehicle_each_phase[1] = (num_vehicle[2] + num_vehicle[8]) #2
        num_vehicle_each_phase[2] = (num_vehicle[10] + num_vehicle[4]) #3
        num_vehicle_each_phase[3] = (num_vehicle[5] + num_vehicle[11]) #4
        num_vehicle_each_phase[4] = (num_vehicle[2] + num_vehicle[1]) # 5
        num_vehicle_each_phase[5] = (num_vehicle[5] + num_vehicle[4]) #6
        num_vehicle_each_phase[6] = (num_vehicle[7] + num_vehicle[8]) #7 
        num_vehicle_each_phase[7] = (num_vehicle[10] + num_vehicle[11]) # 8

        


        action = np.argmax(num_vehicle_each_phase) + 1
        # print(f'num_vehicle_each_phase {num_vehicle_each_phase}')
        # print(f'action selected {action}')
        return action


    def count_num_vehicle_near_intersection(self, intersection_id, new_info, distance = 200):
        # count number of vehicle near distance to intersection
        intersection_id = str(int(intersection_id))
        num_vehicle_each_lane = [0]*24
        for vehicle_info in new_info[intersection_id]:
          
            if str(int(vehicle_info['road'][0])) in [self.intersection_road_segment[intersection_id][key] for key in self.intersection_road_segment[intersection_id].keys() ] :
                
                road_segment_id = str(int(vehicle_info['road'][0]))
                intersection = self.intersection_road_segment[intersection_id]

                drivable = str(int(vehicle_info['drivable'][0]))

                if road_segment_id == intersection['road1']:
                    lane_number = self.which_lane('road1', drivable)

                if road_segment_id == intersection['road2']:
                    lane_number = self.which_lane('road2', drivable)

                if road_segment_id == intersection['road3']:
                    lane_number  = self.which_lane('road3', drivable)

                if road_segment_id == intersection['road4']:
                    lane_number  = self.which_lane('road4', drivable) 

                if road_segment_id == intersection['road5']:
                    lane_number  = self.which_lane('road5', drivable)

                if road_segment_id == intersection['road6']:
                    lane_number  = self.which_lane('road6', drivable)

                if road_segment_id == intersection['road7']:
                    lane_number  = self.which_lane('road7', drivable)

                if road_segment_id == intersection['road8']:
                    lane_number  = self.which_lane('road8', drivable)

                
                this_road_len = self.road_len[road_segment_id]
                if this_road_len - vehicle_info['distance'][0] <= distance:
                    
                    num_vehicle_each_lane[lane_number - 1] += 1

        return [0] + num_vehicle_each_lane

    def which_lane(self, road_name, drivable) -> int:

        lane_name = drivable[-2:] # '00', '01', '02'
        lane_number = self.lane_number[road_name][lane_name]
        return lane_number




scenario_dirs = [
    "test"
]

agent_specs = dict.fromkeys(scenario_dirs, None)
for i, k in enumerate(scenario_dirs):
    # initialize an AgentSpec instance with configuration
    agent_specs[k] = TestAgent()




    # after each 40sec, agent at each intersection will change phase, each time it changes phase, redline 5sec
    # the reward is how much traffic it has reduce in its intersection