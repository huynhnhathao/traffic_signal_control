""" Required submission file

In this file, you should implement your `AgentSpec` instance, and **must** name it as `agent_spec`.
As an example, this file offers a standard implementation.
"""
import copy
import os
path = os.path.split(os.path.realpath(__file__))[0]
import sys
sys.path.append(path)

from pathlib import Path
import gym
import numpy as np
import logging

import torch

import torch
import torch.nn as nn 
import pickle

from MemoryReplay import *
from Policies import *


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)

gym.logger.setLevel(gym.logger.INFO)


# path = os.path.split(os.path.realpath(__file__))[0]
# sys.path.append(path)

class DQN(object):
    def __init__(self, memory, model, target_model, args):
        """
        parameters:
            memory: instance of MemoryReplay class
            model: instance of a nn class
        """
        self.args = args
        self.memory = memory
        self.model = model
        self.target_model = target_model
        self.update_target_network()

        self.agent_list = []
        self.phase_passablelane = {}
        self.policy = self.args['policy']
        self.gamma = self.args['gamma']
        # for epsilon greedy
        self.epsilon = self.args['start_epsilon']
        print(f'epsilone {self.epsilon}')

        self.epsilon_min = self.args['epsilon_min']
        self.action_space = 8
        # track the number of times calling the one_step_training method
        self.num_steps_training = 0

        self.optimizer = torch.optim.Adam(self.model.parameters(), lr = self.args['learning_rate'] )
        self.loss_function = nn.SmoothL1Loss()

    ################################
    # don't modify this function.
    # agent_list is a list of agent_id
    def load_agent_list(self,agent_list):
        self.agent_list = agent_list
        self.now_phase = dict.fromkeys(self.agent_list,1)
        self.last_change_step = dict.fromkeys(self.agent_list,0)
    # intersections[key_id] = {
    #     'have_signal': bool,
    #     'end_roads': list of road_id. Roads that end at this intersection. The order is random.
    #     'start_roads': list of road_id. Roads that start at this intersection. The order is random.
    #     'lanes': list, contains the lane_id in. The order is explained in Docs.
    # }
    # roads[road_id] = {
    #     'start_inter':int. Start intersection_id.
    #     'end_inter':int. End intersection_id.
    #     'length': float. Road length.
    #     'speed_limit': float. Road speed limit.
    #     'num_lanes': int. Number of lanes in this road.
    #     'inverse_road':  Road_id of inverse_road.
    #     'lanes': dict. roads[road_id]['lanes'][lane_id] = list of 3 int value. Contains the Steerability of lanes.
    #               lane_id is road_id*100 + 0/1/2... For example, if road 9 have 3 lanes, then their id are 900, 901, 902
    # }
    # agents[agent_id] = list of length 8. contains the inroad0_id, inroad1_id, inroad2_id,inroad3_id, outroad0_id, outroad1_id, outroad2_id, outroad3_id
    # each agent has control over 8 roads, which made up one intersection(eight is the most, there maybe has 3 legs intersection which has only 6 roads)

    def load_roadnet(self,intersections, roads, agents):
        self.intersections = intersections
        self.roads = roads
        self.agents = agents
    ################################

    def save_model(self,model_name ):
        saved_path = path + model_name
        torch.save(self.model.state_dict(), saved_path)
        print(f'Model saved to {saved_path}')

    def update_epsilon(self):
        r = max((self.args['max_training_steps'] - self.num_steps_training)/self.args['max_training_steps'], 0 )
        self.epsilon = (self.args['start_epsilon'] - self.args['epsilon_min'])*r + self.args['epsilon_min']

    def sample(self):
        # randomly sample action
        return np.random.randint(0, self.action_space)

    def act_(self, observations_for_agent, ):
        #This function return action for training, using epsilon greedy or boltzmann policy
        actions = {}
        with torch.no_grad():
            for agent_id in self.agent_list:
                # print(observations_for_agent[agent_id])
                action = self.get_action(observations_for_agent[agent_id])
                actions[agent_id] = action 

        return actions

    def act(self, obs):
        # this function is for inferences, use greedy policy 100%
        observations = obs['observations']
        #info = obs['info']
        actions = {}

        # Get state
        observations_for_agent = {}
        for key,val in observations.items():
            observations_agent_id = int(key.split('_')[0])
            observations_feature = key[key.find('_')+1:]
            if(observations_agent_id not in observations_for_agent.keys()):
                observations_for_agent[observations_agent_id] = {}
            observations_for_agent[observations_agent_id][observations_feature] = val[1:]

        # Get actions
        # inference do not need gradient
        with torch.no_grad():
            for agent in self.agent_list:
                # plus 1 because action range from 1 to 8, not 0 to 7
                q_values = self.model(observations_for_agent[agent]['lane_vehicle_num'] )
            
                actions[agent] = torch.argmax(q_values).item() + 1
                #actions[agent] = self.get_action(observations_for_agent[agent]['lane_vehicle_num']) + 1  

        return actions

    def get_action(self, ob, ):

        # The epsilon-greedy action selector.

        if np.random.rand() < self.epsilon:
            return np.random.randint(0, self.action_space)
        else:
            # print(f'observation before reshape {ob}' )
            ob = self._reshape_observation(ob)
            # print(f'Observation after reshape {ob}')
            
            q_values = self.model(ob.float())
            # print(f'q_values {q_values}' )
            action = torch.argmax(q_values.squeeze(0), ).item() 
            # print(f'action {action}')
            return   action 

    def epsilon_greedy(self, q_values):
        """
        Epsilon greedy policy
        """
        if not hasattr(self, 'epsilon') :
            raise AttributeError("epsilon not specified")

        # q_values is a torch tensor
        #q_values = q_values.view(1, -1)
        #print(f'self.epsilon {self.epsilon}')
        if np.random.rand() < self.epsilon:
            return self.sample()
        else:
        #    print(q_values)
           return torch.argmax(q_values.squeeze(0), ).item()

    def _reshape_observation(self, observation):
        # 1 row
        # this should be a pytorch tensor
        # we change it later
        try:
            return torch.from_numpy(np.reshape(observation['lane'], (1, -1)), )
        except:
            return torch.from_numpy(np.reshape(observation, (1, -1)), )

    def calculate_target(self,  rewards, next_states, dones,):
        """
        Calculate the Q_tar for each example in batch
        states, actions, rewards, next_states, dones are expected to be pytorch tensors
        """

        online_next_q_preds = self.model(next_states)
        online_actions = torch.argmax(online_next_q_preds, dim = 1)  # 

        # print(online_next_q_preds)
        # print(online_actions)
        next_q_values =  self.target_model(next_states)


        max_next_q_values = next_q_values.gather(1,  online_actions.long().unsqueeze(-1) )

        targets = rewards + self.gamma*max_next_q_values*(1 - dones.int())
        # print(f'reward {rewards}')
        # print(f'target {targets}')
        return targets

    def predict_q_values(self, states, actions):
        """
        Predict q values of all action
        parameters: 
            states: tensor of shape [batch_size, state_size]
            actions: tensor of shape[batch_size]
        return a tensor of shape [batch_size] of predicted q value for each sample
        this time we need gradient
        """
        predicted = self.model(states).gather(1, actions.long())
        # logger.info(f'Q value predicted {predicted}')
        # writer.add_graph(self.model, states)
        return predicted


    def L2_weight_regularization(self, l2_lambda):
        """Return the L2 regularization of the policy weights"""
        l2_reg = torch.tensor(0.)
        for param in self.model.parameters():
            l2_reg += torch.norm(param)
        return l2_reg*l2_lambda

    def update_target_network(self):
        self.target_model.load_state_dict(copy.deepcopy(self.model.state_dict()))
        # This function has tested and worked properly 
        # logger.info('Udated target net')

    def one_step_training(self, ):
        """
        Do one step training model here
        For some first update, the target net should be the original model
        """
        self.model.train()
        this_step_losses = []
        # using_target_net = self.num_steps_training >= self.args['start_using_target_network']
        for i in range(self.args['num_batchs_per_step']):
            # sample a batch from memory
            states, actions, rewards, next_states, dones = self.memory.sample(CER = True)
            # logger.info(f'inside one batch sampling, states {states} \n, actions {actions} \n, rewards {rewards} \n, next_states {next_states}\n , dones {dones}\n')
            # logger.info(f'Rewards {rewards}')
            for u in range(self.args['num_update_per_batch']):
                # calculate target, loss, do an update
                # logger.info(f'inside one update')
                self.optimizer.zero_grad()
                #logger.info('after zerograd')
                self.model.eval()
                with torch.no_grad():
                    targets = self.calculate_target( rewards, next_states, dones)
                self.model.train()
                # logger.info(f'target computed {targets}')
                preds = self.predict_q_values(states, actions)
                # logger.info(f'predicted q values {preds}')
                # logger.info(f'target shape {targets.size()} predicted shape {preds.size()}') #This ok [64, 1]

                loss = self.loss_function(preds, targets)
                #loss += self.L2_weight_regularization(self.l2_lambda)
                #logger.info(f'after zero grad, before call backward {self.model.linear1.weight.grad}')
                loss.backward()
                #logger.info(f'after backward,  {self.model.linear1.weight.grad}')
                #norms = torch.nn.utils.clip_grad_norm_(self.model.parameters(),100 )
                #logger.info(f'after clip norm linear1 {self.model.linear1.weight.grad} \n linear2{self.model.linear2.weight.grad} \n linear3{self.model.linear3.weight.grad} \n with norm {norms}')
                self.optimizer.step()
                this_step_losses.append(loss.detach().item())  
                
            self.num_steps_training +=1
        #self.update_boltzmann_temperature()
        #logger.info(f'Called one_step_training {self.num_steps_training},  loss = {np.mean(this_step_losses)}')

    def train(self, num_episode = None):
        """
        call one_step_training multiple time
        """

        for i in range(self.args['num_steps_training']):
            self.one_step_training()
            if self.num_steps_training  % self.args['update_target_net_freq'] == 0:
                self.update_target_network()
            if i % 50000 - 1 == 0:
                cloned_model = copy.deepcopy(self.model)
                cloned_model.to('cpu')
                torch.save(cloned_model.state_dict(), f'/starter-kit/saved_models/model_episode_{i+ 200000}.pt')




scenario_dirs = ["test" ]
memory = MemoryReplay(200000, 64, 42,)

net = MLPPolicy(72, 8)
target_net = MLPPolicy(72, 8)
# net.load_state_dict(torch.load('/starter-kit/saved_models/models_not_scaled_reward/model_trained_on_random_actions/model_episode_250001.pt'))
# print('Model loaded')

agent_specs = dict.fromkeys(scenario_dirs, None)
args = {
    'max_training_steps': 500000, 
    'update_target_net_freq': 1000, 
    'training_start': 50000, # start training when the memory has more than 1000 experience
    # after this number of time of num_step_training, the target model will be updated to the model
    'gamma': 0.95, 
    'start_epsilon': 1, 
    'epsilon_min' : 0.01, 
    'learning_rate': 0.005, 
    'num_batchs_per_step': 1, 
    'num_update_per_batch': 1, 
    # after 4 time call the one_step_training not using target net, start using target network
    'l2_lambda': 0.01, 
    "policy": 'epsilon', 

    # how many training step before start using target net
}
for i, k in enumerate(scenario_dirs):
    # initialize an AgentSpec instance with configuration
    agent_specs[k] = DQN(memory,net ,target_net,args)
