from collections import deque, namedtuple
import random
import numpy as np
import torch
import copy
import os
path = os.path.split(os.path.realpath(__file__))[0]
import sys
sys.path.append(path)

import pickle

class SequenceMemoryReplay(object):
    """Memmory class to save experiences"""
    def __init__(self, maxlen,batch_size, seed, device = 'cpu'):
        """
        params:
            maxlen: max len of memory
            batch_size: number of experiences are sampled each time sample is called
            seed: set seed for random, for reproducible purpose
        """
        self.num_experiences = 0
        self.maxlen = maxlen
        self.seed = seed
        self.memory = deque(maxlen  = self.maxlen)
        self.experience = namedtuple('Experience', field_names= ['state', 'action', 'reward', 'next_state', 'done'])
        self.batch_size = batch_size
        self.device = device
        self.experiences_of_agents = {}
        self.num_time_steps = 10
        self.observation_len = 80
        # random.seed(self.seed)


    def init_experiences_of_agents(self, agent_list):
        for agent in agent_list:
            self.experiences_of_agents[agent] = []

        print('Memory has initiated')

    def sample(self, n_experiences = None):
        """
        Sample n_experiences from the memory
        return pytorch tensors of experiences: states, actions, rewards, next_states, dones 
        """
        if n_experiences is None:
            n_experiences = self.batch_size
        
        samples = random.sample(self.memory, n_experiences)
        states, actions, rewards, next_states, dones = np.array([x.state for x in samples]) , np.array([x.action for x in samples]), np.array([x.reward for x in samples]),\
         np.array([x.next_state for x in samples]), np.array([x.done for x in samples])
         
        # logger.info(f'1 example of experience sample from memory: state: {states[0]} action: {actions[0]} reward {rewards[0]} next_state: {next_states[0]} done: {dones[0]}')
        assert type(states) == np.ndarray, 'states is expected to be np.ndarray'
        # assert len(states) == len(actions) == len(rewards) == len(next_states) == len(dones), 'len does not match'

        states = torch.from_numpy(states).float().to(self.device)
        actions = torch.from_numpy(actions).float().unsqueeze(-1).to(self.device)
        rewards = torch.from_numpy(rewards).float().unsqueeze(-1).to(self.device)
        next_states = torch.from_numpy(next_states).float().to(self.device)
        dones = torch.from_numpy(dones).float().unsqueeze(-1).to(self.device)
        # logger.info(f'Shape of tensor return from memory class: \n states.size() = {states.size()}, actions.size() = {actions.size()}, rewards.size() = {rewards.size()}, next_states.size() = {next_states.size()}, dones.size() = {dones.size()}')
        # is the shape right?
        return states, actions, rewards, next_states, dones

    def add_experience(self, experience):
        """
        this add only 1 tuple of (state, action, reward, next_state)
        """
        self.num_experiences += 1
        if self.num_experiences %10000 == 0:
            print(f'added 10k experiences to memory, total experiences now {self.num_experiences}')

        agent_id = experience[0]
        experience = self.experience(experience[1],experience[2],experience[3],experience[4],experience[5] )

        self.experiences_of_agents[agent_id].append(experience)

        self.construct_sequence_experience(agent_id)

    def construct_sequence_experience(self, agent_id, num_time_steps = None):
        """
        Construct one sequence experience, each sequence experience include num_time_steps observation from the environment 
        include current observation
        action is the current action
        reward is the current reward, 
        next_state is the num_time_steps observations from the environment include the next observation
        return a named tuple experience contains state, action, reward, next_state
        """
        if num_time_steps is None:
            num_time_steps = self.num_time_steps

        state = np.zeros((num_time_steps, self.observation_len))
        action = None
        reward = None
        done =  None
        next_state = np.zeros((num_time_steps, self.observation_len))
        # Get the 9 last observations of that agent


        if len(self.experiences_of_agents[agent_id]) < num_time_steps:
            state[-len(self.experiences_of_agents[agent_id]) : ] = [x.state for x in self.experiences_of_agents[agent_id]]
            if len(self.experiences_of_agents[agent_id]) < num_time_steps - 1:
                next_state[-len(self.experiences_of_agents[agent_id]):-1] = [ x.state for x in self.experiences_of_agents[agent_id]]
                next_state[-1] = self.experiences_of_agents[agent_id][-1].next_state

        else:
            state = [x.state for x in self.experiences_of_agents[agent_id][-num_time_steps:] ]
            next_state[:-1] = [x.state for x in self.experiences_of_agents[agent_id][-num_time_steps:]]
            next_state[-1] = self.experiences_of_agents[agent_id][-1].next_state

        action, reward, done = self.experiences_of_agents[agent_id].action, self.experiences_of_agents[agent_id].reward, self.experiences_of_agents[agent_id].done

        assert len(state[0]) == self.observation_len

        sequence_experience = self.experience(state, action, reward, next_state, done)
        self.memory.append(sequence_experience)


    def __len__(self):
        return len(self.memory)

    def save_experiencies(self, episode, epsilon,):
        save_dir = f'/saved_data/episode_{episode}_epsilon_{epsilon}.pkl'
        save_dir = path + save_dir
        if not os.path.exists(path + '/saved_data'):
            os.makedirs(path + '/saved_data', exist_ok= True)

        print(f"saving data to {save_dir}")
        with open(save_dir, 'wb') as f:
            pickle.dump([list(x) for x in self.memory], f)

    def load_data(self, data_path):
        """
        load data from dist to memory
        """    
        data = pickle.load(open(path + data_path, 'rb'))
        for e in data:
            self.add_experience(e)

        print("Data Loaded successfully to memory")


class MemoryReplay(object):
    """Memmory class to save experiences"""
    def __init__(self, maxlen,batch_size, seed, device = 'cpu'):
        """
        params:
            maxlen: max len of memory
            batch_size: number of experiences are sampled each time sample is called
            seed: set seed for random, for reproducible purpose
        """
        self.num_experiences = 0
        self.maxlen = maxlen
        self.seed = seed
        self.memory = deque(maxlen  = self.maxlen)
        self.experience = namedtuple('Experience', field_names= ['state', 'action', 'reward', 'next_state', 'done'])
        self.batch_size = batch_size
        self.device = device
        # random.seed(self.seed)

    
    def sample(self, n_experiences = None, CER = True):
        """
        Sample n_experiences from the memory
        return pytorch tensors of experiences: states, actions, rewards, next_states, dones 
        """
        if n_experiences is None:
            n_experiences = self.batch_size
        
        samples = random.sample(self.memory, n_experiences)
        if CER:
            samples[-1] = self.memory[-1]
            
        states, actions, rewards, next_states, dones = np.array([x.state for x in samples]) , np.array([x.action for x in samples]), np.array([x.reward for x in samples]),\
         np.array([x.next_state for x in samples]), np.array([x.done for x in samples])
         
        # logger.info(f'1 example of experience sample from memory: state: {states[0]} action: {actions[0]} reward {rewards[0]} next_state: {next_states[0]} done: {dones[0]}')
        assert type(states) == np.ndarray, 'states is expected to be np.ndarray'
        # assert len(states) == len(actions) == len(rewards) == len(next_states) == len(dones), 'len does not match'

        states = torch.from_numpy(states).float().to(self.device)
        actions = torch.from_numpy(actions).float().unsqueeze(-1).to(self.device)
        rewards = torch.from_numpy(rewards).float().unsqueeze(-1).to(self.device)
        next_states = torch.from_numpy(next_states).float().to(self.device)
        dones = torch.from_numpy(dones).float().unsqueeze(-1).to(self.device)
        # logger.info(f'Shape of tensor return from memory class: \n states.size() = {states.size()}, actions.size() = {actions.size()}, rewards.size() = {rewards.size()}, next_states.size() = {next_states.size()}, dones.size() = {dones.size()}')
        # is the shape right?
        return states, actions, rewards, next_states, dones



    def add_experience(self, experience):
        """
        Add many experiences to the memory
        this add only 1 tuple of (state, action, reward, next_state)
        """
        self.num_experiences += 1
        if self.num_experiences %10000 == 0:
            print(f'added 10k experiences to memory, total experiences now {self.num_experiences}')

        experience = self.experience(*experience)
        self.memory.append(experience)

    def __len__(self):
        return len(self.memory)

    def save_experiencies(self, episode, epsilon,):
        save_dir = f'/saved_data/episode_{episode}_epsilon_{epsilon}.pkl'
        save_dir = path + save_dir
        if not os.path.exists(path + '/saved_data'):
            os.makedirs(path + '/saved_data', exist_ok= True)

        print(f"saving data to {save_dir}")
        with open(save_dir, 'wb') as f:
            pickle.dump([list(x) for x in self.memory], f)

    def load_data(self, data_path):
        """
        load data from dist to memory
        """    
        data = pickle.load(open(path + data_path, 'rb'))
        for e in data:
            self.add_experience(e)

        print("Data Loaded successfully to memory")



if __name__ == '__main__':
    print('MemoryReplay module')
