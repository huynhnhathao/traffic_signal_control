
import torch
import torch.nn as nn 


class MLPPolicy(nn.Module):
    def __init__(self, in_dim, out_dim):
        """Create a MLP neural network to be a policy
        parameters: 
            in_dim: int,  input dimension
            out_dim: int, output dimension
        return: logits
        """
        super(MLPPolicy, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        
        self.linear1 = nn.Linear(self.in_dim, 512)
        self.linear2 = nn.Linear(512, 256)
        self.linear3 = nn.Linear(256,128 )
        self.linear4 = nn.Linear(128, 8)

        self.tanh = nn.Tanh()
        # self.softmax = nn.Softmax(dim = 0)
    
    def forward(self, x):
        x = self.linear1(x)
        x = self.tanh(x)
        x = self.linear2(x)
        x = self.tanh(x)
        x = self.linear3(x)
        x = self.tanh(x)
        x = self.linear4(x)
        return x


class LSTMPolicy(nn.Module):
    def __init__(self):
        raise NotImplementedError()

if __name__ == '__main__':
    print('Policies module')