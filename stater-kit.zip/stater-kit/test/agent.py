import pickle
import gym
from pathlib import Path
import pickle
import gym
import numpy as np
# how to import or load local files
import os
import sys
path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(path)
import gym_cfg
with open(path + "/gym_cfg.py", "r") as f:
    pass

import torch
import torch.nn as nn
import multiprocessing
from copy import deepcopy

            
class MLPPolicy(nn.Module):
    def __init__(self, in_dim, out_dim):
        """Create a MLP neural network to be a policy
        parameters: 
            in_dim: int,  input dimension
            out_dim: int, output dimension
        return: logits
        """
        super(MLPPolicy, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        
        self.linear1 = nn.Linear(self.in_dim, 512)
        self.linear2 = nn.Linear(512, 256)
        self.linear3 = nn.Linear(256,128 )
        self.linear4 = nn.Linear(128, 8)

        self.tanh = nn.Tanh()
        # self.softmax = nn.Softmax(dim = 0)
    
    def forward(self, x):
        x = self.linear1(x)
        x = self.tanh(x)
        x = self.linear2(x)
        x = self.tanh(x)
        x = self.linear3(x)
        x = self.tanh(x)
        x = self.linear4(x)
        return x

            

class TestAgent():
    def __init__(self, ):

        self.count = -1
        self.now_phase = {}
        self.last_change_step = {}
        self.agent_list = []
        self.phase_passablelane = {}
        self.intersections = {}
        self.roads = {}
        self.agents = {}
        self.lane_number = { 'road1': {'00': 13, '01': 14, '02': 15  }, 
                            'road2': {'00': 1, '01': 2, '02': 3}, 
                            'road3': {'00': 16, '01': 17, '02': 18}, 
                            'road4': {'00': 4, '01': 5, '02': 6}, 
                            'road5': {'00': 19, '01': 20, '02': 21}, 
                            'road6': {'00': 7, '01': 8, '02': 9}, 
                            'road7': {'00': 22, '01': 23 , '02':24 }, 
                            'road8': {'00':10 , '01': 11, '02':12 ,}
        }
        self.memory = []
        self.intersection_road_segment = pickle.load(open(path + '/intersection_road_segment1.pkl', 'rb'))
        self.road_segment_len = pickle.load(open(path + '/road_segment_len.pkl', 'rb'))

        self.convert_lane = {1:19, 2:20, 3:21, 4:22, 5:23, 6:24, 7:13, 8:14, 9:15, 10:16, 11:17, 12:18, 
                            13:7, 14:8, 15:9, 16:10, 17:11, 18:12, 19:1, 20:2, 21:3, 22:4, 23: 5, 24:6 }

        self.intersection_data, self.road_data, self.traffic_signal_data = self.load_data()
        # self.agent_list = list(self.intersection_road_segment.keys())
        self.road_len = self.get_road_len()
        self.neighbor_intersection_data = pickle.load(open(path + '/neighbor_intersection_data.pkl', 'rb'))

        self.available_phases_data = pickle.load(open(path + '/available_phases_data.pkl', 'rb'))

        self.policy = self.load_policy()

        self.vehicles_on_roads_ = pickle.load(open(path + '/vehicles_on_roads.pkl', 'rb'))

        self.reset_vehicles_on_roads()
    ################################
    # don't modify this function.
    # agent_list is a list of agent_id
    def load_agent_list(self,agent_list):
        self.agent_list = agent_list
        self.now_phase = dict.fromkeys(self.agent_list,1)
        self.last_change_step = dict.fromkeys(self.agent_list,1)
        

    # intersections[key_id] = {
    #     'have_signal': bool,
    #     'end_roads': list of road_id. Roads that end at this intersection. The order is random.
    #     'start_roads': list of road_id. Roads that start at this intersection. The order is random.
    #     'lanes': list, contains the lane_id in. The order is explained in Docs.
    # }
    # roads[road_id] = {
    #     'start_inter':int. Start intersection_id.
    #     'end_inter':int. End intersection_id.
    #     'length': float. Road length.
    #     'speed_limit': float. Road speed limit.
    #     'num_lanes': int. Number of lanes in this road.
    #     'inverse_road':  Road_id of inverse_road.
    #     'lanes': dict. roads[road_id]['lanes'][lane_id] = list of 3 int value. Contains the Steerability of lanes.
    #               lane_id is road_id*100 + 0/1/2... For example, if road 9 have 3 lanes, then their id are 900, 901, 902
    # }
    # agents[agent_id] = list of length 8. contains the inroad0_id, inroad1_id, inroad2_id,inroad3_id, outroad0_id, outroad1_id, outroad2_id, outroad3_id
    def load_roadnet(self,intersections, roads, agents):
        self.intersections = intersections
        self.roads = roads
        self.agents = agents
    ################################

    def reset_vehicles_on_roads(self):
        self.vehicles_on_roads = deepcopy(self.vehicles_on_roads_)

    def load_policy(self,model_name = '/starter-kit/saved_models/models_not_scaled_reward/model_trained_on_random_actions/model_episode_49999_epsilon_1.pt' ):
        path_to_state_dict = model_name
        policy = MLPPolicy(72, 8)
        policy.load_state_dict(torch.load(path_to_state_dict))
        return policy

    def save_memory(self, saved_path = path + '/testing_states_saved.pkl'):
        with open(saved_path, 'wb') as f:
            pickle.save(self.memory, f)

        print('testing memory saved')

    def load_data(self, file_name = '/roadnet_round2.txt'):
        """
        load in road net data, extract len for each road segment id
        """
        data = []
        #dir = os.path.join(sys.path[0],file_name )  
        with open(path + file_name , 'r') as f:
            for line in f.readlines():
                numbers = line.split(' ')
                data.append(list([float(x) for x in numbers ]))

        intersection_data = data[:2049]
        road_data = data[2049:11086]
        traffic_signal_data = data[11086:]
        return intersection_data, road_data, traffic_signal_data

    def get_road_len(self) -> dict:
        # return a dict of road segment len
        road_len = {}
        for x in self.road_data:
            if len(x) == 8:
                road_len[str(int(x[6]))] = x[2]
                road_len[str(int(x[7]))] = x[2] 

        return road_len

    def update_vehicles_on_roads(self, infos, min_speed = 1):
        """
        this method update the number of vehicles on all roads segment of the road network
        each road_id is a dict, contains number of vehicle on its lanes's segments and number of vehicle that not moving 
        and the from_intersection and to intersection
        """
        self.reset_vehicles_on_roads()
        for vehicle_id, info in infos.items():
            road_id_of_this_vehicle = str(int(info['road'][0]))
            drivable = str(int(info['drivable'][0]))
            lane_of_this_vehicle = drivable[-2:]
            this_road_len = self.road_len[road_id_of_this_vehicle]

            segment = None
            # segment 0 is the nearest entering intersection
            if info['distance'][0] <= this_road_len/3:
                segment = 2
            elif info['distance'][0] <= (2/3)*this_road_len:
                segment = 1
            else:
                segment = 0

            self.vehicles_on_roads[road_id_of_this_vehicle]['num_vehicle_on_lanes'][f'lane{lane_of_this_vehicle}'][segment] += 1

            if info['speed'][0] < min_speed:
                self.vehicles_on_roads[road_id_of_this_vehicle]['num_vehicle_waiting_on_lanes'][f'lane{lane_of_this_vehicle}'][segment] += 1

    def which_road(self, lane_number):
        # take in a lane number and return which road that lane in
        if lane_number in [1,2,3]:
            return 'road2'
        elif lane_number in [13, 14, 15]:
            return 'road1'
        elif lane_number in [4, 5, 6]:
            return 'road4'
        elif lane_number in [16,17,18]:
            return 'road3'
        elif lane_number in [7,8,9]:
            return 'road6'
        elif lane_number in [19,20,21]:
            return 'road5'
        elif lane_number in [10, 11, 12]:
            return 'road8'
        elif lane_number in [22,23,24]:
            return 'road7'

    def normalize_num_vehicles(self, num_vehicles):
        """
        normalize num_vehicle of segments of lanes of each intersection by its segment len(segment len = lane_len / 3 )
        """
        for intersection_id in num_vehicles.keys():
            assert len(num_vehicles[intersection_id]) == 24*3
            this_intersection_data = self.intersection_road_segment[intersection_id]
            # print(f'before transform {num_vehicles[intersection_id]}')
            for road_name, data in this_intersection_data.items():
                # for each road name in this intersection
                if data['id'] != '-1':
                    
                    # if this road of this intersection exist
                    lanes = list((np.array(list  (self.lane_number[road_name].values())) - 1)*3 )
                    temp_lanes = []
                    for lane in lanes:
                        temp_lanes.extend([lane +1, lane + 2])

                    lanes.extend(temp_lanes)

                    try:
                        segment_len = data['len']/15 # 3*5
                    except:
                        print(f"id {data['id']} len {data['len']} ")
        
                    num_vehicles[intersection_id][lanes]/= segment_len

            #         print(f"road name {road_name}  lanes {lanes} segmentlen {segment_len} len {data['len']}")
            # print(f'after transform {num_vehicles[intersection_id]}')


        return num_vehicles

    def get_num_vehicle_on_road(self, road_name, num_vehicles):
        """
        count number of vehicles on one road, include 3 lanes, only count on the first segments of these lanes
        num_vehicles is a list of 24*3 elements, 
        only count num vehicle on the first segment of lanes of one road, which mean 3 segments
        road_name is road1, road2, ...
        """
        lanes = None
        if road_name in self.lane_number.keys():
            lanes = self.lane_number[road_name].values()

        # tem contains indices of 3 segments for each lane of 3 lanes of road_name
        # temp = []
        # for lane in lanes:
        #     temp.append(lane)
        #     temp.append(lane +1)
        #     temp.append(lane + 2)

        total_vehicle = np.sum([num_vehicles[(x-1)*3] for x in lanes])
        return total_vehicle

    def which_lane(self, road_name, drivable) -> int:

        lane_name = drivable[-2:] # '00', '01', '02'
        lane_number = self.lane_number[road_name][lane_name]
        return lane_number


    def test_new_observation(self, new_observation, old_observation):
        for agent_id in self.agent_list:
            t1 = sum([x if x >=0 else 0 for x in new_observation[str(agent_id)]])
            t2 = sum([x if x>=0 else 0 for x in old_observation[agent_id]['lane_vehicle_num'][1:]])
            assert t1 == t2


    def act(self, obs):
        """ 
        Taking observation from CBEngine env, return actions for each agent
        """
        self.count += 1
        if self.count % 3 != 0:
            return {}
        observations = obs['observations']
        infos = obs['info']

        observations_for_agent = {}
        for key,val in observations.items():
            observations_agent_id = int(key.split('_')[0])
            observations_feature = key[key.find('_')+1:]
            if(observations_agent_id not in observations_for_agent.keys()):
                observations_for_agent[observations_agent_id] = {}
            observations_for_agent[observations_agent_id][observations_feature] = val

        self.update_vehicles_on_roads(infos)

        new_observations = self.get_new_observations()

        self.test_new_observation(new_observations, observations_for_agent)

        actions = {}
        with torch.no_grad():
            for agent in self.agent_list:
                action = self.get_action(new_observations[str(agent)])
                if action in self.available_phases_data[str(agent)]:
                    actions[agent] = action
                else:
                    actions[agent] = np.random.choice(self.available_phases_data[str(agent)], 1)

        self.last_change_step = actions
        return actions

    def get_action(self, observation):
        """
        get action for a single agent
        param: observation: observation for a single agent, expected to be an array of size 24*3
        """
        observation = torch.tensor(observation, dtype= torch.float).unsqueeze(0)
        q_values = self.policy(observation)
        return torch.argmax(q_values) + 1


    def get_new_observations(self,):
        """
        take in info of one state, 
        return a dict, its keys are agent list, its values is a list of 24*3 element
        each lane has 3 segment, we use the number of vehicle on each segment, from nearest 
        intersection out, (normalized by the segment length)
        """
        observations = {}
        for agent_id, agent_info in self.intersection_road_segment.items():
            observations[agent_id] = [0]*72
            
            # get observation for this agent
            if agent_info['road2']['id'] != '-1':
                this_road_id = agent_info['road2']['id']
                observations[agent_id][:3] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
                observations[agent_id][3:6] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][6:9] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']

            else:
                # if this road is not exist, then pad the number of vehicle by -1
                observations[agent_id][:9] = [-1]*9

            if agent_info['road4']['id'] != '-1':
                this_road_id = agent_info['road4']['id']
                observations[agent_id][9:12] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
                observations[agent_id][12:15] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][15:18] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']

            else:
                observations[agent_id][9:18] = [-1]*9

            if agent_info['road6']['id'] != '-1':
                this_road_id = agent_info['road6']['id']
                observations[agent_id][18:21] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
                observations[agent_id][21:24] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][24:27] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']

            else:
                observations[agent_id][18:27] = [-1]*9

            if agent_info['road8']['id'] != '-1':
                this_road_id = agent_info['road8']['id']
                observations[agent_id][27:30] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
                observations[agent_id][30:33] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][33:36] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']

            else:
                observations[agent_id][27:36] = [-1]*9

            if agent_info['road1']['id'] != '-1':
                this_road_id = agent_info['road1']['id']
                observations[agent_id][36:39] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']
                observations[agent_id][39:42] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][42:45] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
            else:
                observations[agent_id][36:45] =[-1]*9

            if agent_info['road3']['id'] != '-1':
                this_road_id = agent_info['road3']['id']
                observations[agent_id][45:48] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']
                observations[agent_id][48:51] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][51:54] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
            else:
                observations[agent_id][45:54] = [-1]*9   

            if agent_info['road5']['id'] != '-1':
                this_road_id = agent_info['road5']['id']
                observations[agent_id][54:57] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']
                observations[agent_id][57:60] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][60:63] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
            else:
                observations[agent_id][54:63] = [-1]*9                       

            if agent_info['road7']['id'] != '-1':
                this_road_id = agent_info['road7']['id']
                observations[agent_id][63:66] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane02']
                observations[agent_id][66:69] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane01']
                observations[agent_id][69:] = self.vehicles_on_roads[this_road_id]['num_vehicle_on_lanes']['lane00']
            else:
                observations[agent_id][63:] = [-1]*9     
           
        # scaled_num_vehicles = self.normalize_num_vehicles(deepcopy(observations))
        return observations

    def add_onehot_action_to_observation(self, observations):
        for agent in self.agent_list:
            observations[str(agent)] = np.array(list(observations[str(agent)]) + self.get_onehot_current_phase(self.last_change_step[agent]))
            # assert len(observations[str(agent)]) == 80

        return observations

    def get_onehot_current_phase(self, action):

        current_phase = [0]*8
        current_phase[int(action) - 1] = 1
        return current_phase


scenario_dirs = [
    "test"
]

agent_specs = dict.fromkeys(scenario_dirs, None)

for i, k in enumerate(scenario_dirs):
    # initialize an AgentSpec instance with configuration
    agent_specs[k] = TestAgent()