
# from pathlib import Path
import pickle
# import gym
import multiprocessing
# how to import or load local files
import os
import sys
path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(path)
import gym_cfg
with open(path + "/gym_cfg.py", "r") as f:
    pass
import numpy as np
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__file__)
logger.propagate = False
fh = logging.FileHandler('simulation_data.log')
fh.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

#now we only consider vehicle that near the intersection 100m, on which lane, phase which has more vehicle on its passable lanes 
# will go first
class TestAgent():
    def __init__(self):
        self.count = -1
        self.now_phase = {}
        self.green_sec = 30
        self.max_phase = 8
        self.last_change_step = {}
        self.agent_list = []
        self.phase_passablelane = {}
        self.intersections = {}
        self.roads = {}
        self.agents = {}
        self.intersection_data, self.road_data, self.traffic_signal_data = self.load_data()
        self.road_len = self.get_road_len()
        self.intersection_road_segment = pickle.load(open(path + '/intersection_road_segment1.pkl', 'rb'))
        # {'42266617929': {'road1': {'id': '327',
        #                 'len': 788.0,
        #                 'speed_limit': 11.11111111111111},
        #                 'road3': {'id': '3', 'len': 771.0, 'speed_limit': 16.666666666666668},
        #                 'road5': {'id': '3984', 'len': 704.0, 'speed_limit': 13.88888888888889},
        #                 'road7': {'id': '3985', 'len': 703.0, 'speed_limit': 13.88888888888889},
        #                 'road2': {'id': '328', 'len': 788.0, 'speed_limit': 11.11111111111111},
        #                 'road4': {'id': '4', 'len': 771.0, 'speed_limit': 16.666666666666668},
        #                 'road6': {'id': '3983', 'len': 704.0, 'speed_limit': 13.88888888888889},
        #                 'road8': {'id': '3986', 'len': 703.0, 'speed_limit': 13.88888888888889}},
        # }
        self.road_segment_len = pickle.load(open(path + '/road_segment_len.pkl', 'rb'))
        # '4': {'len': 771.0, 'speed_limit': 16.666666666666668},
        self.neighbor_intersection_data = pickle.load(open(path + '/neighbor_intersection_data.pkl', 'rb'))
        self.lane_number = { 'road1': {'00': 13, '01': 14, '02': 15  }, 
                            'road2': {'00': 1, '01': 2, '02': 3}, 
                            'road3': {'00': 16, '01': 17, '02': 18}, 
                            'road4': {'00': 4, '01': 5, '02': 6}, 
                            'road5': {'00': 19, '01': 20, '02': 21}, 
                            'road6': {'00': 7, '01': 8, '02': 9}, 
                            'road7': {'00': 22, '01': 23 , '02':24 }, 
                            'road8': {'00':10 , '01': 11, '02':12 ,}
        }
        self.convert_lane = {1:19, 2:20, 3:21, 4:22, 5:23, 6:24, 7:13, 8:14, 9:15, 10:16, 11:17, 12:18, 
                            13:7, 14:8, 15:9, 16:10, 17:11, 18:12, 19:1, 20:2, 21:3, 22:4, 23: 5, 24:6 }
        
    ################################
    # don't modify this function.
    # agent_list is a list of agent_id
    def load_agent_list(self,agent_list):
        self.agent_list = agent_list
        self.now_phase = dict.fromkeys(self.agent_list,1)
        self.last_change_step = dict.fromkeys(self.agent_list,0)

    # intersections[key_id] = {
    #     'have_signal': bool,
    #     'end_roads': list of road_id. Roads that end at this intersection. The order is random.
    #     'start_roads': list of road_id. Roads that start at this intersection. The order is random.
    #     'lanes': list, contains the lane_id in. The order is explained in Docs.
    # }
    # roads[road_id] = {
    #     'start_inter':int. Start intersection_id.
    #     'end_inter':int. End intersection_id.
    #     'length': float. Road length.
    #     'speed_limit': float. Road speed limit.
    #     'num_lanes': int. Number of lanes in this road.
    #     'inverse_road':  Road_id of inverse_road.
    #     'lanes': dict. roads[road_id]['lanes'][lane_id] = list of 3 int value. Contains the Steerability of lanes.
    #               lane_id is road_id*100 + 0/1/2... For example, if road 9 have 3 lanes, then their id are 900, 901, 902
    # }
    # agents[agent_id] = list of length 8. contains the inroad0_id, inroad1_id, inroad2_id,inroad3_id, outroad0_id, outroad1_id, outroad2_id, outroad3_id
    def load_roadnet(self,intersections, roads, agents):
        self.intersections = intersections
        self.roads = roads
        self.agents = agents
    ################################


    def load_data(self, file_name = '/roadnet_round2.txt'):
        """
        load in road net data, extract len for each road segment id
        """
        data = []
        #dir = os.path.join(sys.path[0],file_name )  
        with open(path + file_name , 'r') as f:
            for line in f.readlines():
                numbers = line.split(' ')
                data.append(list([float(x) for x in numbers ]))

        intersection_data = data[:2049]
        road_data = data[2049:11086]
        traffic_signal_data = data[11086:]
        return intersection_data, road_data, traffic_signal_data

    def get_road_len(self) -> dict:
        # return a dict of road segment len
        road_len = {}
        for x in self.road_data:
            if len(x) == 8:
                road_len[str(int(x[6]))] = x[2]
                road_len[str(int(x[7]))] = x[2] 

        return road_len


    def check_road(self, road_segment_id):
        # check if this road_segment_id is one of the exitting roads of signalized intersection

        for line in self.traffic_signal_data:
            if road_segment_id in line:
                print(line)
                return True

    def which_intersection(self, vehicle_info):
        """
        return which intersection this vehicle belong to
        lane_number is count from 1 -> 24
        """

        road_id = str(int(vehicle_info['road'][0]))

        for intersection_id, road_ids in self.intersection_road_segment.items():

            for road_name in road_ids.keys():
                if road_id == road_ids[road_name]['id'] and road_name in ['road2', 'road4' , 'road6', 'road8']:
                        
                    drivable = str(int(vehicle_info['drivable'][0]))
                    lane_number = self.which_lane(road_name, drivable)
 
                    this_road_len = self.road_len[road_id]
                    # which segment does this vehicle on this lane?
                    segment = 0
                    if this_road_len - vehicle_info['distance'][0] < this_road_len/3:
                        segment = 0
                    elif this_road_len - vehicle_info['distance'][0] < (2/3)*this_road_len:
                        segment = 1
                    else:
                        segment = 2

                    neighbor_intersection_id, neighbor_lane_number, neigbor_segment = self.get_neighbor_data(intersection_id, lane_number, segment)

                        #print(f'intersection {intersection_id} road_id {road_ids[road]} road_name {road} drivable {drivable} lane_number {lane_number } len road {this_road_len} ')
                    return [(intersection_id, lane_number, segment), (neighbor_intersection_id, neighbor_lane_number, neigbor_segment)]

        return [(None, None, None), (None, None, None)]

    def which_road(self, lane_number):
        # take in a lane number and return which road that lane in
        if lane_number in [1,2,3]:
            return 'road2'
        elif lane_number in [13, 14, 15]:
            return 'road1'
        elif lane_number in [4, 5, 6]:
            return 'road4'
        elif lane_number in [16,17,18]:
            return 'road3'
        elif lane_number in [7,8,9]:
            return 'road6'
        elif lane_number in [19,20,21]:
            return 'road5'
        elif lane_number in [10, 11, 12]:
            return 'road8'
        elif lane_number in [22,23,24]:
            return 'road7'


    def get_neighbor_data(self, intersection_id, lane_number, segment):
        """
        return neighbor intersection of intersection_id that link with it via road_name, 
        and lane number w.r.t the neighbor, and segment of vehicle w.r.t the neighbor
        neighbor_lane is counted from 1 -> 24
        """
        neighbor_intersection_ids = self.neighbor_intersection_data[intersection_id]
        road = self.which_road(lane_number)
        if road not in neighbor_intersection_ids.keys():
            return (None, None, None)
        else:
            neighbor_intersection_id = neighbor_intersection_ids[road]

        neighbor_lane_number = self.convert_lane[lane_number]
        neighbor_segment = None
        if segment == 0:
            neighbor_segment = 2
        elif segment == 1:
            neighbor_segment = 1
        elif segment == 2:
            neighbor_segment = 0
        if neighbor_segment is None:
            raise ValueError('can not convert neighbor segment')

        return (neighbor_intersection_id, neighbor_lane_number, neighbor_segment)

    def normalize_num_vehicles(self, num_vehicles):
        """
        normalize num_vehicle of segments of lanes of each intersection by its segment len(segment len = lane_len / 3 )
        """
        for intersection_id in num_vehicles.keys():
            assert len(num_vehicles[intersection_id]) == 24*3
            this_intersection_data = self.intersection_road_segment[intersection_id]
            # print(f'before transform {num_vehicles[intersection_id]}')
            for road_name, data in this_intersection_data.items():
                # for each road name in this intersection
                if data['id'] != '-1':
                    
                    # if this road of this intersection exist
                    lanes = list((np.array(list  (self.lane_number[road_name].values())) - 1)*3 )
                    temp_lanes = []
                    for lane in lanes:
                        temp_lanes.extend([lane +1, lane + 2])

                    lanes.extend(temp_lanes)

                    try:
                        segment_len = data['len']/3
                    except:
                        print(f"id {data['id']} len {data['len']} ")
        
                    num_vehicles[intersection_id][lanes]/= segment_len

            #         print(f"road name {road_name}  lanes {lanes} segmentlen {segment_len} len {data['len']}")
            # print(f'after transform {num_vehicles[intersection_id]}')


        return num_vehicles

    def act(self, obs):
        self.count += 1
        if  self.count %3 == 0:
            pass
        else:
            return {}
        observations = obs['observations']
        # an example of observations: {'0_lane_speed': [0, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2], 
        # '0_lane_vehicle_num': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}
        info = obs['info']
        num_vehicles = {}
        for intersection_id in self.agent_list:
            num_vehicles[str(intersection_id)] = np.zeros(24*3)

        # for vehicle_id, vehicle_info in info.items():
        #     intersection, lane_number = self.which_intersection(vehicle_info)

        #     if intersection is None:
        #         continue
        #     num_vehicles[intersection][lane_number - 1] += 1
        #    # print(f'intersection id {intersection} lane number {lane_number} num vehicle {num_vehicles[intersection]}')
        # with multiprocessing.Pool() as p:
        #     results = p.map(self.which_intersection, info.values())

        with multiprocessing.Pool() as p:
            results = p.map(self.which_intersection, info.values())


        for result in results:

            if result[0][0] is not None:
                num_vehicles[result[0][0]][(result[0][1] - 1)*3 + result[0][2] ] += 1
                if result[1][0] is not None:
                    num_vehicles[result[1][0]][(result[1][1] - 1)*3 + result[1][2] ] += 1

        # each lane segment vehicle number is normalized by its lane segment length
        num_vehicles = self.normalize_num_vehicles(num_vehicles)

        # for result in results:
        #     if result[0] is not None:

        #         num_vehicles[result[0]][result[1] - 1] += 1

        actions = {}    

        # a simple fixtime agent

        # preprocess observations
        observations_for_agent = {}


        for key,val in observations.items():
            observations_agent_id = int(key.split('_')[0])
            observations_feature = key[key.find('_')+1:]
            # print(key, val)
            if(observations_agent_id not in observations_for_agent.keys()):
                observations_for_agent[observations_agent_id] = {}
            observations_for_agent[observations_agent_id][observations_feature] = val

        # what observation_for_agent look like?
        """
        {0: {'lane_speed': [190, -2, -2, -2, 0.0, -2, -2, 0.0, 0.0, -2, 0.0, 0.0, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2],
            'lane_vehicle_num': [190, 0, 0, 0, 2, 0, 0, 3, 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}}
        """

       # get actions
        for agent in self.agent_list:
            # select the now_step
            for k,v in observations_for_agent[agent].items():
                # the currently second
                now_step = v[0]
                break
            step_diff = now_step - self.last_change_step[agent]
            if(step_diff >= self.green_sec):
                self.now_phase[agent] = self.get_actions( num_vehicles[str(agent)], observations_for_agent[agent]['lane_vehicle_num'])
                self.last_change_step[agent] = now_step
            actions[agent] = self.now_phase[agent]
        # print(self.intersections,self.roads,self.agents)
        # actions = self.get_actions(observations_for_agent)
        # self.last_change_step = actions
        print(actions)
        return actions

    def get_num_vehicle_on_road(self, road_name, num_vehicles):
        """
        num_vehicles is a list of 24*3 elements, 
        each element except first element is the number of vehicle on that lane
        road_name is road1, road2, ...
        """
        lanes = None
        if road_name in self.lane_number.keys():
            lanes = self.lane_number[road_name].values()
        
        
        total_vehicle = np.sum([num_vehicles[(x-1)*3] for x in lanes])
        return total_vehicle

    def get_unavailable_phases(self, lane_vehicle_num):
        self.phase_lane_map_in = [[1, 7], [2, 8], [4, 10], [5, 11], [2, 1], [5, 4], [8, 7], [11, 10]]
        unavailable_phases = []
        not_exist_lanes = []
        for i in range(1, 25):
            if lane_vehicle_num[i] < 0:
                not_exist_lanes.append(i)
        for lane in not_exist_lanes:
            for phase_id, in_lanes in enumerate(self.phase_lane_map_in):
                phase_id += 1
                if lane in in_lanes and phase_id not in unavailable_phases:
                    unavailable_phases.append(phase_id)

        return unavailable_phases

    def get_actions(self,num_vehicle,  lane_vehicle_num):
        """
        number of vehicle on all passable lanes of one phase, from 1 to 8, does not include right turning lanes
        agent is agent id
        observation_for_agent is a dict of lane speed and lane_vehicle_num
        """
        num_vehicle_each_phase = np.zeros(8)

        #num_vehicle = self.count_num_vehicle_near_intersection(intersection_id, new_info, distance )
        # print(f'observation num vehicle: {observation_num_vehicle}')
        # print(f'num vehicle near intersection {num_vehicle}')
   
  
        num_vehicle =  list(num_vehicle)
        # print(intersection_id)
        # print(num_vehicle)
        #assert len(num_vehicle) == 25

        # for i, num in enumerate(lane_vehicle_num[1:]):
        #     lane_number = i
        #     if num < 0:

        #         num_vehicle[lane_number*3] = -99999

        road1 = self.get_num_vehicle_on_road('road1', num_vehicle)
        road3 = self.get_num_vehicle_on_road('road3', num_vehicle)
        road5 = self.get_num_vehicle_on_road('road5', num_vehicle)
        road7 = self.get_num_vehicle_on_road('road7', num_vehicle)

        # print(f'road1 {road1} road3 {road3} road5 {road5} road7 {road7}')

        num_vehicle_each_phase[0] = (num_vehicle[(1 - 1)*3] + num_vehicle[(7 - 1 )*3]) - (road3 + road7)/3 #1
        num_vehicle_each_phase[1] = (num_vehicle[(2 - 1)*3] + num_vehicle[(8 - 1)*3]) - (road1 + road5)/3 #2
        num_vehicle_each_phase[2] = (num_vehicle[(10 - 1)*3] + num_vehicle[(4 - 1)*3]) - (road1 + road5)/3 #3
        num_vehicle_each_phase[3] = (num_vehicle[(5 - 1)*3] + num_vehicle[(11 - 1)*3]) -(road3 + road7)/3 #4
        num_vehicle_each_phase[4] = (num_vehicle[(2 - 1)*3] + num_vehicle[(1 - 1)*3]) - (road5 + road3)/3 # 5
        num_vehicle_each_phase[5] = (num_vehicle[(5 - 1)*3] + num_vehicle[(4 - 1)*3]) - (road7 + road5)/3 #6
        num_vehicle_each_phase[6] = (num_vehicle[(7 - 1)*3] + num_vehicle[(8 - 1)*3]) - (road1 + road7)/3 #7 
        num_vehicle_each_phase[7] = (num_vehicle[(10 - 1)*3] + num_vehicle[(11 - 1)*3]) -(road1 + road3)/3 # 8

        non_exist_phases = self.get_unavailable_phases(lane_vehicle_num)
        # print(f'lane vehicle num {lane_vehicle_num}')
        # print(f'num_vehicle {num_vehicle}')
        # print(f'numvehicle each phase {num_vehicle_each_phase}')
        # print(f'none exist phase {non_exist_phases}')

        for phase in non_exist_phases:
            num_vehicle_each_phase[phase - 1] = -np.inf
        action = np.argmax(num_vehicle_each_phase) + 1

        # print(f'num_vehicle_each_phase {num_vehicle_each_phase}')
        # print(f'action selected {action}')
        if action is None:
            raise ValueError('action is None')
        # print(action)
        return action

    def which_lane(self, road_name, drivable) -> int:

        lane_name = drivable[-2:] # '00', '01', '02'
        lane_number = self.lane_number[road_name][lane_name]
        return lane_number




    
scenario_dirs = [
    "test"
]

agent_specs = dict.fromkeys(scenario_dirs, None)
for i, k in enumerate(scenario_dirs):
    # initialize an AgentSpec instance with configuration
    agent_specs[k] = TestAgent()


# after each 40sec, agent at each intersection will change phase, each time it changes phase, redline 5sec
# the reward is how much traffic it has reduce in its intersection