import multiprocessing as mp
import concurrent.futures
import time
def my_func(x):
    time.sleep(1)
    return x


# if __name__ == '__main__':
#     start = time.time()

#     with mp.Pool() as pool:
#         results = pool.map(my_func, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])




#     end = time.time()
#     print(f'results {results}')
#     print(f'time taken {end - start}')


if __name__ == '__main__':
    start = time.time()

    with concurrent.futures.ProcessPoolExecutor() as executor:
        results = executor.map(my_func, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])


    end = time.time()
    print(f'results {results}')
    print(f'time taken {end - start}')