
from TrainingUtilities import *
# import datetime
import CBEngine
import json
import traceback
import argparse
import logging
import os
import sys
import time
from pathlib import Path
# import re
import gym
import numpy as np
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__file__)
logger.setLevel(logging.INFO)

data_logger = logging.getLogger(__file__)
data_logger.setLevel(logging.ERROR)

gym.logger.setLevel(gym.logger.INFO)
from env_wrapper import spawn_env

class Trainer(object):
    """Train an agent with random search"""
    def __init__(self, args, agent_specs, simulator_cfg_file, gym_cfg, metric_period):
    

        self.args = args

        self.agent_spec = agent_spec
        # self.simulator_cfg_file = simulator_cfg_file
        # self.gym_cfg = gym_cfg
        # self.metric_period = metric_period
        # self.simulator_configs = read_config(self.simulator_cfg_file)
        # self.gym_configs = gym_cfg.cfg
        # self.env = gym.make('CBEngine-v0', simulator_cfg_file = self.simulator_cfg_file,
        #                     thread_num = 4,
        #                     gym_dict = self.gym_configs,
        #                     metric_period = self.metric_period 
        #                     )
        self.env = spawn_env()
        
                            
        # self.roadnet_path = Path(self.simulator_configs['road_file_addr'])
        #self.intersections, self.roads, self.agents = process_roadnet(self.roadnet_path)


        self.scenario = ["test"]
        #agent is the agent instance
        self.agent = agent_specs[self.scenario[0]]


        # self.agent.memory.init_experiences_of_agents(self.env.agent_list)

        
        self.agent_id_list =  [ x for x in self.env.agent_list]
        
    def get_agent_id_list(self, observations):
        """Get the agent_id_list from observation and return it"""
        agent_id_list = []
        for k in observations:

            agent_id_list.append(int(k.split('_')[0]))
        agent_id_list = list(set(agent_id_list))
        return agent_id_list

    def transform_action(self, actions):
        """This take an action dict, plus all action to 1"""
        actions_ = {}
        for key in actions.keys():
            actions_[key] = actions[key] + 1
        return actions_

    def train(self, ):
        

        # test
        

        logger.info("\n")
        logger.info("*" * 100)

        last_obs, infos = self.env.reset()

        self.agent.load_agent_list(self.env.agent_list)

        for e in range(self.args.episodes):
            # self.agent.update_epsilon(e)
            print("-"*50 ,"- Episode {}/{}".format(e + 1, self.args.episodes))
            print(f"current training step: {self.agent.num_steps_training}/{self.agent.args['max_training_steps']}")
            print(f'Current epsilon {self.agent.epsilon}')
            print("-"*50 ,"- Episode {}/{}".format(e + 1, self.args.episodes))
            last_obs, _ = self.env.reset()
            
            # every agent has it own rewards save in episodes_rewards
            # episodes_rewards = dict.fromkeys(self.env.agent_list, 0)
            i = 0
            while True: 
                if i% 10 == 0:
                    print(i)
                i+=1
                if True:# i % self.args.action_interval == 0:
                    data_logger.info(f'Last obs is {last_obs}')
                    # action's keys will be the itersection ids, and its action will be the phase
                    actions = {}

                    observations_for_agent = last_obs
                    # from here we have completed the observations_for_agent dict
                    actions = self.agent.act_(observations_for_agent)
                    data_logger.info(f'actions before transform {actions}')
                    #print(f'actions {actions}')

                    # plus 1 because environment take action from [1 to 8]
                    actions_ = self.transform_action(actions)
                    data_logger.info(f'actions after transform {actions_}')

                    new_observations_for_agent, rewards, dones, infos = self.env.step(actions_)

                    # Remember (state, action, reward, next_state) into memory buffer.
                    for agent_id in self.env.agent_list:
                        self.agent.memory.add_experience((observations_for_agent[agent_id], actions[agent_id], rewards[agent_id],
                                    new_observations_for_agent[agent_id], dones))
                    
                    if len(self.agent.memory) > self.agent.args['training_start']:
                        for j in range(0, 400):
                            self.agent.one_step_training()

                        self.agent.update_epsilon()
                        self.agent.update_target_network()


                        # episodes_rewards[agent_id] += rewards[agent_id] 

                    # count the number of experiences

                    last_obs = new_observations_for_agent
                
                if dones:
                    break
                
            # self.agent.memory.save_experiencies(e + 6, self.agent.epsilon)
            
            #self.agent.train()

            self.agent.save_model(model_name = f'/saved_models/{self.agent.num_steps_training}_{self.agent.epsilon}.pt')

            

if __name__ == "__main__":
    # arg parse
    print('*'*500)
    parser = argparse.ArgumentParser(
        prog="evaluation",
        description="1"
    )

    parser.add_argument(
        "--input_dir",
        help="The path to the directory containing the reference "
             "data and user submission data.",
        default= 'agent',
        type=str,
    )

    parser.add_argument(
        "--output_dir",
        help="The path to the directory where the submission's "
             "scores.txt file will be written to.",
        default='out',
        type=str,
    )

    parser.add_argument(
        "--sim_cfg",
        help='The path to the simulator cfg',
        default='cfg/simulator.cfg',
        type=str
    )

    parser.add_argument(
        "--metric_period",
        help="period of scoring",
        default=3600,
        type=int
    )
    parser.add_argument(
        "--threshold",
        help="period of scoring",
        default=1.6,
        type=float
    )

    parser.add_argument('--thread', type=int, default=8, help='number of threads')
    parser.add_argument('--steps', type=int, default=120, help='number of steps')
    # because each time call env.step(), 10 sec passed, so 4 here mean call env.step() 4 time, 40 sec passed
    # in the env, and 4 sec of redlight
    parser.add_argument('--action_interval', type=int, default=3, help='how often agent make decisions')
    parser.add_argument('--episodes', type=int, default=10 , help='training episodes')

    parser.add_argument('--save_model', action="store_true", default=False)
    parser.add_argument('--load_model', action="store_true", default=False)
    parser.add_argument("--save_rate", type=int, default=2,
                        help="save model once every time this many episodes are completed")
    parser.add_argument('--save_dir', type=str, default="model/dqn_warm_up",
                        help='directory in which model should be saved')
    parser.add_argument('--log_dir', type=str, default="cmd_log/dqn_warm_up", help='directory in which logs should be saved')

    # result to be written in out/result.json
    result = {
        "success": False,
        "error_msg": "",
        "data": {
            "total_served_vehicles": -1,
            "delay_index": -1
        }
    }

    args = parser.parse_args()
    # args = edict({
    #     'action_interval'=2, 
    #     'episodes'=100,
    #     'input_dir'='agent',
    #     'load_model'=False,
    #     'log_dir'='cmd_log/dqn_warm_up',
    #     'metric_period'=3600, output_dir='out',
    #     'save_dir'='model/dqn_warm_up', save_model=False,
    #     'save_rate'=5, sim_cfg='cfg/simulator.cfg',
    #     steps=360, thread=8, threshold=1.6
    # })


    msg = None
    metric_period = args.metric_period
    threshold = args.threshold
    # get input and output directory
    simulator_cfg_file = args.sim_cfg
    try:
        submission_dir, scores_dir = resolve_dirs(
            os.path.dirname(__file__), args.input_dir, args.output_dir
        )
    except Exception as e:
        msg = format_exception(e)
        result['error_msg'] = msg
        json.dump(result, open(scores_dir / "scores.json", 'w'), indent=2)
        raise AssertionError()

    # get agent and configuration of gym
    try:
        agent_spec, gym_cfg = load_agent_submission(submission_dir)
    except Exception as e:
        msg = format_exception(e)
        result['error_msg'] = msg
        json.dump(result, open(scores_dir / "scores.json", 'w'), indent=2)
        raise AssertionError()

    logger.info(f"Loaded user agent instance={agent_spec}")

    # simulation
    start_time = time.time()
    try:

        #---------------------------------------------------------------------------------
        # print('-'*100)
        # print(f'args {args}')
        logger.info('\n Trainer called here'+ '-'*100 + '\n')
        trainer = Trainer(args, agent_spec, simulator_cfg_file, gym_cfg, metric_period)
        trainer.train()
        logger.info(f"Total number of times called one_step_training {trainer.agent.num_steps_training}")
        scores = run_simulation(agent_spec, simulator_cfg_file, gym_cfg, metric_period, scores_dir, threshold)
    except Exception as e:
        msg = format_exception(e)
        result['error_msg'] = msg
        json.dump(result, open(scores_dir / "scores.json", 'w'), indent=2)
        raise AssertionError()

    # write result
    result['data']['total_served_vehicles'] = scores[0]
    result['data']['delay_index'] = scores[1]
    # result['data']['last_d_i'] = scores[2]
    result['success'] = True

    # cal time
    end_time = time.time()

    logger.info(f"total evaluation cost {end_time - start_time} s")

    # write score
    logger.info("\n\n")
    logger.info("*" * 40)

    json.dump(result, open(scores_dir / "scores.json", 'w'), indent=2)

    logger.info("Evaluation complete")


# trainer = Trainer()
# agent_specs is a dictionary, its key is "test" and its value is the agent instance